# Findr Full-Screen Map: EBWBL Integration Plan

## Executive Summary
Implement a tiered bathymetry/substrate mapping system using EMODnet's EBWBL (World Base Layer) as primary source with intelligent fallbacks to standard EMODnet services for optimal performance and detail.

---

## Data Source Architecture

### Tier 1: EBWBL (Primary - Full Screen)
- **Service Type**: WMTS (Web Map Tile Service)
- **Resolution**: Highest available (combines EMODnet DTM + GEBCO)
- **Performance**: Pre-rendered tiles = faster loading
- **Coverage**: Global with enhanced European waters
- **Use Case**: Full-screen map primary layer

### Tier 2: Standard EMODnet (Fallback)
- **Service Type**: WMS/WCS
- **Resolution**: 1/16 arc-minute (~115m)
- **Coverage**: European seas
- **Use Cases**:
  - Mini map (lighter load)
  - Fallback when EBWBL unavailable
  - Areas outside EBWBL coverage

### Tier 3: Local Cache (Performance)
- **Type**: IndexedDB/Service Worker
- **Purpose**: Offline capability & performance
- **Retention**: 7 days for frequently viewed areas

---

## Technical Implementation

### 1. Service Configuration

```typescript
// /src/config/mapServices.ts

export const MapServices = {
  ebwbl: {
    bathymetry: {
      url: 'https://tiles.emodnet-bathymetry.eu/wmts',
      layer: 'emodnet-bathymetry-ebwbl',
      format: 'image/png',
      projection: 'EPSG:3857', // Web Mercator
      matrixSet: 'EPSG:3857',
      attribution: 'EMODnet Bathymetry Consortium (EBWBL)',
      maxZoom: 14,
      minZoom: 2,
      cache: true
    }
  },
  
  standard: {
    bathymetry: {
      url: 'https://ows.emodnet-bathymetry.eu/wms',
      layer: 'emodnet:mean_atlas_land',
      format: 'image/png',
      attribution: 'EMODnet Bathymetry Consortium',
      maxZoom: 12
    },
    
    substrate: {
      url: 'https://ows.emodnet-geology.eu/wms',
      layer: 'emodnet-geology:seabed_substrate',
      format: 'image/png',
      attribution: 'EMODnet Geology'
    }
  },
  
  // Spain-specific services if available
  regional: {
    spain: {
      url: 'https://www.ieo.es/services/wms', // If available
      layers: ['bathymetry_hr', 'substrate'],
      bounds: [[43.2, -9.3], [43.8, -3.0]] // Asturias bounds
    }
  }
};
```

### 2. Intelligent Layer Manager

```typescript
// /src/hooks/useLayerManager.ts

import { useState, useEffect, useCallback } from 'react';
import L from 'leaflet';
import { MapServices } from '@/config/mapServices';

interface LayerState {
  active: 'depth' | 'seabed' | 'off';
  quality: 'ebwbl' | 'standard' | 'cached';
  loading: boolean;
  error: string | null;
}

export const useLayerManager = (map: L.Map | null, isFullScreen: boolean) => {
  const [layerState, setLayerState] = useState<LayerState>({
    active: 'off',
    quality: 'standard',
    loading: false,
    error: null
  });

  // Check EBWBL availability for current bounds
  const checkEBWBLAvailability = useCallback(async (bounds: L.LatLngBounds) => {
    try {
      // Quick capability check via GetCapabilities
      const response = await fetch(
        `${MapServices.ebwbl.bathymetry.url}?SERVICE=WMTS&REQUEST=GetCapabilities`
      );
      
      if (response.ok) {
        // Parse response to verify layer availability
        return true;
      }
    } catch (error) {
      console.warn('EBWBL not available, falling back to standard');
    }
    return false;
  }, []);

  // Smart layer loader with fallback
  const loadLayer = useCallback(async (
    type: 'depth' | 'seabed',
    bounds: L.LatLngBounds
  ) => {
    setLayerState(prev => ({ ...prev, loading: true, error: null }));
    
    let layer: L.TileLayer | null = null;
    let quality: 'ebwbl' | 'standard' = 'standard';

    try {
      // Try EBWBL first for full-screen
      if (isFullScreen && type === 'depth') {
        const ebwblAvailable = await checkEBWBLAvailability(bounds);
        
        if (ebwblAvailable) {
          layer = L.tileLayer(
            `${MapServices.ebwbl.bathymetry.url}/{z}/{x}/{y}.png`,
            {
              attribution: MapServices.ebwbl.bathymetry.attribution,
              maxZoom: MapServices.ebwbl.bathymetry.maxZoom,
              minZoom: MapServices.ebwbl.bathymetry.minZoom,
              bounds: bounds,
              crossOrigin: true
            }
          );
          quality = 'ebwbl';
        }
      }

      // Fallback to standard EMODnet
      if (!layer) {
        const config = type === 'depth' 
          ? MapServices.standard.bathymetry 
          : MapServices.standard.substrate;
          
        layer = L.tileLayer.wms(config.url, {
          layers: config.layer,
          format: config.format,
          transparent: true,
          attribution: config.attribution,
          maxZoom: config.maxZoom
        });
      }

      if (map && layer) {
        layer.addTo(map);
        setLayerState({
          active: type,
          quality,
          loading: false,
          error: null
        });
      }
      
      return layer;
      
    } catch (error) {
      setLayerState(prev => ({
        ...prev,
        loading: false,
        error: 'Failed to load layer. Using cached data if available.'
      }));
      
      // Attempt to load from cache
      return loadCachedLayer(type, bounds);
    }
  }, [map, isFullScreen]);

  return { layerState, loadLayer };
};
```

### 3. Progressive Enhancement Strategy

```typescript
// /src/components/MapView/ProgressiveMapLoader.tsx

import React, { useEffect, useState } from 'react';
import { useMapState } from '@/hooks/useMapState';
import { useLayerManager } from '@/hooks/useLayerManager';

interface MapQualityIndicator {
  source: 'EBWBL' | 'EMODnet' | 'Cached';
  resolution: string;
  coverage: number; // percentage
}

export const ProgressiveMapLoader: React.FC<{ 
  map: L.Map;
  isFullScreen: boolean;
}> = ({ map, isFullScreen }) => {
  const [quality, setQuality] = useState<MapQualityIndicator>({
    source: 'EMODnet',
    resolution: '115m',
    coverage: 100
  });

  const { layerState, loadLayer } = useLayerManager(map, isFullScreen);

  useEffect(() => {
    if (!isFullScreen) {
      // Mini map: always use standard EMODnet (lighter)
      setQuality({
        source: 'EMODnet',
        resolution: '115m',
        coverage: 100
      });
      return;
    }

    // Full screen: attempt progressive enhancement
    const enhanceQuality = async () => {
      const bounds = map.getBounds();
      const zoom = map.getZoom();

      // Zoom level determines data source selection
      if (zoom > 10) {
        // High zoom: try EBWBL first
        const layer = await loadLayer('depth', bounds);
        
        if (layerState.quality === 'ebwbl') {
          setQuality({
            source: 'EBWBL',
            resolution: '<100m',
            coverage: 100
          });
        }
      } else {
        // Lower zoom: standard is sufficient
        setQuality({
          source: 'EMODnet',
          resolution: '115m',
          coverage: 100
        });
      }
    };

    enhanceQuality();
  }, [isFullScreen, map.getZoom()]);

  // Quality indicator badge
  return (
    <div className="absolute top-16 right-4 z-[1000]">
      <div className="badge badge-sm badge-ghost gap-1">
        <span className="text-xs opacity-70">Source:</span>
        <span className="font-medium">{quality.source}</span>
        {quality.resolution && (
          <>
            <span className="opacity-50">•</span>
            <span className="text-xs">{quality.resolution}</span>
          </>
        )}
      </div>
    </div>
  );
};
```

### 4. Performance Optimization

```typescript
// /src/utils/tileCache.ts

class TileCache {
  private cache: Cache | null = null;
  private readonly CACHE_NAME = 'findr-map-tiles-v1';
  private readonly MAX_AGE = 7 * 24 * 60 * 60 * 1000; // 7 days

  async initialize() {
    if ('caches' in window) {
      this.cache = await caches.open(this.CACHE_NAME);
    }
  }

  async getTile(url: string): Promise<Response | null> {
    if (!this.cache) return null;
    
    const cached = await this.cache.match(url);
    if (cached) {
      const cachedTime = cached.headers.get('sw-cache-time');
      if (cachedTime && Date.now() - parseInt(cachedTime) < this.MAX_AGE) {
        return cached;
      }
    }
    return null;
  }

  async cacheTile(url: string, response: Response) {
    if (!this.cache) return;
    
    const headers = new Headers(response.headers);
    headers.set('sw-cache-time', Date.now().toString());
    
    const responseToCache = new Response(response.body, {
      status: response.status,
      statusText: response.statusText,
      headers
    });
    
    await this.cache.put(url, responseToCache);
  }

  async preloadArea(bounds: L.LatLngBounds, zoom: number) {
    // Preload tiles for frequently fished areas
    const tiles = this.calculateTilesInBounds(bounds, zoom);
    
    for (const tile of tiles) {
      const url = this.getTileUrl(tile);
      if (!await this.getTile(url)) {
        // Fetch and cache in background
        fetch(url).then(response => {
          if (response.ok) {
            this.cacheTile(url, response.clone());
          }
        }).catch(() => {
          // Silent fail for preloading
        });
      }
    }
  }

  private calculateTilesInBounds(bounds: L.LatLngBounds, zoom: number) {
    // Calculate which tiles cover the bounds at given zoom
    // Implementation details...
    return [];
  }

  private getTileUrl(tile: { x: number; y: number; z: number }) {
    // Generate tile URL based on service
    return `https://tiles.emodnet-bathymetry.eu/wmts/${tile.z}/${tile.x}/${tile.y}.png`;
  }
}

export const tileCache = new TileCache();
```

### 5. User Interface Updates

```typescript
// /src/components/MapView/LayerControls.tsx

import React from 'react';
import { Info } from 'lucide-react';

export const LayerControls: React.FC<{
  activeLayer: 'depth' | 'seabed' | 'off';
  quality: 'ebwbl' | 'standard' | 'cached';
  onLayerChange: (layer: 'depth' | 'seabed' | 'off') => void;
}> = ({ activeLayer, quality, onLayerChange }) => {
  
  const getQualityLabel = () => {
    switch(quality) {
      case 'ebwbl': return 'HD';
      case 'cached': return 'Offline';
      default: return '';
    }
  };

  return (
    <div className="absolute bottom-20 left-4 z-[1000]">
      {/* Segmented Control */}
      <div className="btn-group bg-base-100 rounded-lg shadow-lg">
        <button 
          className={`btn btn-sm ${activeLayer === 'off' ? 'btn-active' : ''}`}
          onClick={() => onLayerChange('off')}
        >
          Off
        </button>
        
        <button 
          className={`btn btn-sm ${activeLayer === 'depth' ? 'btn-active' : ''} relative`}
          onClick={() => onLayerChange('depth')}
        >
          Depth
          {quality === 'ebwbl' && activeLayer === 'depth' && (
            <span className="badge badge-xs badge-primary absolute -top-1 -right-1">HD</span>
          )}
        </button>
        
        <button 
          className={`btn btn-sm ${activeLayer === 'seabed' ? 'btn-active' : ''}`}
          onClick={() => onLayerChange('seabed')}
        >
          Seabed
        </button>
      </div>

      {/* Data Source Info */}
      {activeLayer !== 'off' && (
        <div className="mt-2 text-xs opacity-70 flex items-center gap-1">
          <Info size={12} />
          {quality === 'ebwbl' ? 'High-res bathymetry' : 
           quality === 'cached' ? 'Offline mode' : 
           'Standard resolution'}
        </div>
      )}
    </div>
  );
};
```

---

## Implementation Phases

### Phase 1: Core Infrastructure (Week 1)
- [ ] Set up WMTS tile layer support
- [ ] Implement service configuration
- [ ] Create fallback logic
- [ ] Basic quality indicator

### Phase 2: Performance (Week 2)
- [ ] Implement tile caching
- [ ] Add service worker for offline
- [ ] Preloading for common areas
- [ ] Connection speed detection

### Phase 3: Enhancement (Week 3)
- [ ] Progressive loading animation
- [ ] Quality selection manual override
- [ ] Regional data source integration
- [ ] Error recovery improvements

### Phase 4: Polish (Week 4)
- [ ] Performance metrics
- [ ] User preference persistence
- [ ] Documentation
- [ ] Analytics integration

---

## Configuration Management

```typescript
// /src/config/environment.ts

export const MapConfig = {
  // Feature flags
  features: {
    ebwbl: process.env.NEXT_PUBLIC_ENABLE_EBWBL === 'true',
    regionalData: process.env.NEXT_PUBLIC_ENABLE_REGIONAL === 'true',
    offlineMode: process.env.NEXT_PUBLIC_ENABLE_OFFLINE === 'true'
  },

  // Service endpoints
  services: {
    ebwbl: {
      endpoint: process.env.NEXT_PUBLIC_EBWBL_ENDPOINT || 
                'https://tiles.emodnet-bathymetry.eu/wmts',
      apiKey: process.env.EBWBL_API_KEY // If required
    },
    emodnet: {
      bathymetry: process.env.NEXT_PUBLIC_EMODNET_BATH_ENDPOINT ||
                  'https://ows.emodnet-bathymetry.eu/wms',
      geology: process.env.NEXT_PUBLIC_EMODNET_GEO_ENDPOINT ||
               'https://ows.emodnet-geology.eu/wms'
    }
  },

  // Performance tuning
  performance: {
    maxConcurrentTiles: 6,
    tileTimeout: 5000,
    cacheSize: 100 * 1024 * 1024, // 100MB
    preloadRadius: 2 // tiles around viewport
  }
};
```

---

## Monitoring & Analytics

```typescript
// /src/utils/mapMetrics.ts

export const trackMapPerformance = {
  tileLoadTime: (source: string, duration: number) => {
    // Track tile load performance by source
    analytics.track('map_tile_load', {
      source,
      duration,
      quality: source === 'ebwbl' ? 'hd' : 'standard'
    });
  },

  layerSwitch: (from: string, to: string, reason: 'user' | 'auto') => {
    analytics.track('map_layer_switch', {
      from,
      to,
      reason,
      timestamp: Date.now()
    });
  },

  fallbackTriggered: (primary: string, fallback: string, error: string) => {
    analytics.track('map_fallback_triggered', {
      primary,
      fallback,
      error,
      userAgent: navigator.userAgent
    });
  }
};
```

---

## Error Handling & Recovery

```typescript
// /src/components/MapView/MapErrorBoundary.tsx

export class MapErrorBoundary extends React.Component {
  state = { hasError: false, fallbackMode: null };

  static getDerivedStateFromError(error: Error) {
    // Determine fallback strategy based on error
    if (error.message.includes('EBWBL')) {
      return { hasError: true, fallbackMode: 'standard' };
    } else if (error.message.includes('network')) {
      return { hasError: true, fallbackMode: 'cached' };
    }
    return { hasError: true, fallbackMode: 'minimal' };
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="alert alert-warning">
          <Info className="h-4 w-4" />
          <span>
            Map running in {this.state.fallbackMode} mode. 
            Some features may be limited.
          </span>
        </div>
      );
    }
    
    return this.props.children;
  }
}
```

---

## Testing Strategy

### Unit Tests
- Service availability detection
- Fallback logic
- Cache operations
- Tile URL generation

### Integration Tests
- EBWBL → Standard fallback
- Online → Offline transition
- Progressive enhancement flow
- Error recovery

### Performance Tests
- Tile load times comparison
- Cache hit rates
- Memory usage
- Network bandwidth

---

## Success Metrics

### Technical
- EBWBL availability: >95% for supported areas
- Tile load time: <500ms average
- Cache hit rate: >60% for return users
- Fallback success: 100%

### User Experience
- Full-screen map load: <2s
- Layer switch: <1s
- Offline capability: Core features work
- Error recovery: Transparent to user

---

## Documentation

### User-Facing
- "HD bathymetry available in select areas"
- "Offline maps for your favorite spots"
- "Automatic quality selection based on connection"

### Developer
- Service integration guide
- Fallback chain documentation
- Cache strategy explanation
- Performance tuning guide
