// /src/components/MapView/FullScreenMap.tsx

import React, { useEffect, useState, useCallback, useRef } from 'react';
import { useRouter } from 'next/navigation';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import { 
  ArrowLeft, 
  Plus, 
  Minus, 
  Navigation, 
  Layers, 
  Info,
  Maximize2,
  X 
} from 'lucide-react';
import { useMapState } from '@/hooks/useMapState';
import { useEBWBLLayer } from '@/hooks/useEBWBLLayer';
import { LegendDrawer } from './LegendDrawer';
import { LayerControls } from './LayerControls';
import { QualityIndicator } from './QualityIndicator';

interface FullScreenMapProps {
  initialState?: {
    center: [number, number];
    zoom: number;
    layer?: 'depth' | 'seabed' | 'off';
    spotId?: string;
  };
}

export const FullScreenMap: React.FC<FullScreenMapProps> = ({ initialState }) => {
  const router = useRouter();
  const mapContainer = useRef<HTMLDivElement>(null);
  const mapInstance = useRef<L.Map | null>(null);
  
  const [activeLayer, setActiveLayer] = useState<'depth' | 'seabed' | 'off'>(
    initialState?.layer || 'off'
  );
  const [showLegend, setShowLegend] = useState(false);
  const [isFullscreenAPI, setIsFullscreenAPI] = useState(false);
  const [loadingQuality, setLoadingQuality] = useState<{
    isLoading: boolean;
    source: 'EBWBL' | 'EMODnet' | 'Cache' | null;
  }>({ isLoading: false, source: null });

  const { mapState, updateMapState } = useMapState(initialState);
  const { loadEBWBLLayer, fallbackToStandard, clearLayers } = useEBWBLLayer();

  // Initialize map
  useEffect(() => {
    if (!mapContainer.current || mapInstance.current) return;

    const map = L.map(mapContainer.current, {
      center: mapState.center,
      zoom: mapState.zoom,
      zoomControl: false,
      attributionControl: false
    });

    // Add base layer (OSM or custom)
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      maxZoom: 19,
      attribution: '© OpenStreetMap contributors'
    }).addTo(map);

    // Add attribution control in corner
    L.control.attribution({ position: 'bottomleft' }).addTo(map);

    mapInstance.current = map;

    // Save state on move/zoom
    map.on('moveend zoomend', () => {
      updateMapState({
        center: [map.getCenter().lat, map.getCenter().lng],
        zoom: map.getZoom()
      });
    });

    return () => {
      map.remove();
      mapInstance.current = null;
    };
  }, []);

  // Handle layer changes with EBWBL priority
  const handleLayerChange = useCallback(async (newLayer: 'depth' | 'seabed' | 'off') => {
    if (!mapInstance.current) return;
    
    setLoadingQuality({ isLoading: true, source: null });
    
    // Clear existing overlay layers
    clearLayers(mapInstance.current);
    
    if (newLayer === 'off') {
      setActiveLayer('off');
      setLoadingQuality({ isLoading: false, source: null });
      return;
    }

    try {
      // Try EBWBL first for depth layers
      if (newLayer === 'depth') {
        const success = await loadEBWBLLayer(mapInstance.current, 'bathymetry');
        
        if (success) {
          setLoadingQuality({ isLoading: false, source: 'EBWBL' });
        } else {
          // Fallback to standard EMODnet
          await fallbackToStandard(mapInstance.current, 'bathymetry');
          setLoadingQuality({ isLoading: false, source: 'EMODnet' });
        }
      } else if (newLayer === 'seabed') {
        // Seabed typically only available via standard EMODnet
        await fallbackToStandard(mapInstance.current, 'substrate');
        setLoadingQuality({ isLoading: false, source: 'EMODnet' });
      }
      
      setActiveLayer(newLayer);
      updateMapState({ layer: newLayer });
      
    } catch (error) {
      console.error('Error loading layer:', error);
      setLoadingQuality({ isLoading: false, source: 'Cache' });
      // Attempt offline/cached version
      loadCachedLayer(mapInstance.current, newLayer);
    }
  }, [loadEBWBLLayer, fallbackToStandard, clearLayers]);

  // Zoom controls
  const handleZoom = (direction: 'in' | 'out') => {
    if (!mapInstance.current) return;
    
    if (direction === 'in') {
      mapInstance.current.zoomIn();
    } else {
      mapInstance.current.zoomOut();
    }
  };

  // GPS locate
  const handleLocate = () => {
    if (!mapInstance.current) return;
    
    mapInstance.current.locate({ 
      setView: true, 
      maxZoom: 14,
      enableHighAccuracy: true 
    });
  };

  // Fullscreen API toggle
  const toggleFullscreenAPI = async () => {
    if (!document.fullscreenElement) {
      await document.documentElement.requestFullscreen();
      setIsFullscreenAPI(true);
    } else {
      await document.exitFullscreen();
      setIsFullscreenAPI(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[9999] bg-base-100 flex flex-col h-[100svh] safe-area-inset">
      {/* Header */}
      <header className="h-14 flex items-center justify-between px-3 border-b border-base-300 bg-base-100/95 backdrop-blur">
        <div className="flex items-center gap-3">
          <button 
            onClick={() => router.back()}
            className="btn btn-ghost btn-sm btn-circle"
            aria-label="Back to details"
          >
            <ArrowLeft className="h-5 w-5" />
          </button>
          <h1 className="font-semibold text-lg">Fishing Area</h1>
        </div>
        
        <button
          onClick={toggleFullscreenAPI}
          className="btn btn-ghost btn-sm btn-circle"
          aria-label="Toggle fullscreen"
        >
          {isFullscreenAPI ? <X className="h-5 w-5" /> : <Maximize2 className="h-5 w-5" />}
        </button>
      </header>

      {/* Map Container */}
      <div className="relative flex-1 bg-base-200">
        <div ref={mapContainer} className="absolute inset-0" />

        {/* Quality Indicator */}
        {loadingQuality.source && (
          <QualityIndicator 
            source={loadingQuality.source}
            isLoading={loadingQuality.isLoading}
          />
        )}

        {/* Floating Controls Cluster - Bottom Right */}
        <div className="absolute bottom-4 right-4 flex flex-col gap-2 z-[1000]">
          {/* Zoom Controls */}
          <div className="flex flex-col bg-base-100 rounded-lg shadow-lg">
            <button
              onClick={() => handleZoom('in')}
              className="btn btn-sm btn-square rounded-b-none"
              aria-label="Zoom in"
            >
              <Plus className="h-5 w-5" />
            </button>
            <div className="divider m-0 h-px" />
            <button
              onClick={() => handleZoom('out')}
              className="btn btn-sm btn-square rounded-t-none"
              aria-label="Zoom out"
            >
              <Minus className="h-5 w-5" />
            </button>
          </div>

          {/* GPS Locate */}
          <button
            onClick={handleLocate}
            className="btn btn-sm btn-square bg-base-100 shadow-lg"
            aria-label="Find my location"
          >
            <Navigation className="h-5 w-5" />
          </button>

          {/* Legend Toggle */}
          <button
            onClick={() => setShowLegend(!showLegend)}
            className={`btn btn-sm btn-square shadow-lg ${
              showLegend ? 'btn-primary' : 'bg-base-100'
            }`}
            aria-label="Toggle legend"
            disabled={activeLayer === 'off'}
          >
            <Info className="h-5 w-5" />
          </button>
        </div>

        {/* Layer Controls - Bottom Left */}
        <LayerControls
          activeLayer={activeLayer}
          onLayerChange={handleLayerChange}
          isLoading={loadingQuality.isLoading}
          dataSource={loadingQuality.source}
        />

        {/* Legend Drawer */}
        {showLegend && activeLayer !== 'off' && (
          <LegendDrawer
            activeLayer={activeLayer}
            onClose={() => setShowLegend(false)}
            dataSource={loadingQuality.source}
          />
        )}

        {/* Loading Overlay */}
        {loadingQuality.isLoading && (
          <div className="absolute inset-0 bg-base-100/50 flex items-center justify-center z-[999]">
            <div className="flex flex-col items-center gap-2">
              <span className="loading loading-spinner loading-lg" />
              <p className="text-sm opacity-70">
                Loading {activeLayer === 'depth' ? 'bathymetry' : 'substrate'} data...
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

// Helper function for cached layers
async function loadCachedLayer(map: L.Map, layer: 'depth' | 'seabed') {
  // Check IndexedDB for cached tiles
  if ('caches' in window) {
    const cache = await caches.open('findr-map-tiles-v1');
    // Implementation for loading cached tiles
    console.log('Loading from cache for offline mode');
  }
}
