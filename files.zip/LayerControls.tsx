// /src/components/MapView/LayerControls.tsx

import React from 'react';
import { Layers, Waves, Mountain, X } from 'lucide-react';

interface LayerControlsProps {
  activeLayer: 'depth' | 'seabed' | 'off';
  onLayerChange: (layer: 'depth' | 'seabed' | 'off') => void;
  isLoading?: boolean;
  dataSource?: 'EBWBL' | 'EMODnet' | 'Cache' | null;
}

export const LayerControls: React.FC<LayerControlsProps> = ({
  activeLayer,
  onLayerChange,
  isLoading = false,
  dataSource
}) => {
  return (
    <div className="absolute bottom-4 left-4 z-[1000]">
      {/* Main Segmented Control */}
      <div className="flex bg-base-100 rounded-lg shadow-lg p-1">
        {/* Off Button */}
        <button
          className={`
            btn btn-sm flex-1 gap-1
            ${activeLayer === 'off' 
              ? 'btn-active bg-base-300' 
              : 'btn-ghost'
            }
            ${isLoading ? 'btn-disabled' : ''}
          `}
          onClick={() => onLayerChange('off')}
          disabled={isLoading}
        >
          <X className="h-4 w-4" />
          <span className="hidden sm:inline">Off</span>
        </button>

        {/* Depth Button */}
        <button
          className={`
            btn btn-sm flex-1 gap-1 relative
            ${activeLayer === 'depth' 
              ? 'btn-active bg-primary text-primary-content' 
              : 'btn-ghost'
            }
            ${isLoading && activeLayer === 'depth' ? 'loading' : ''}
          `}
          onClick={() => onLayerChange('depth')}
          disabled={isLoading}
        >
          <Waves className="h-4 w-4" />
          <span>Depth</span>
          {activeLayer === 'depth' && dataSource === 'EBWBL' && (
            <span className="badge badge-xs badge-secondary absolute -top-1 -right-1">
              HD
            </span>
          )}
        </button>

        {/* Seabed Button */}
        <button
          className={`
            btn btn-sm flex-1 gap-1
            ${activeLayer === 'seabed' 
              ? 'btn-active bg-secondary text-secondary-content' 
              : 'btn-ghost'
            }
            ${isLoading && activeLayer === 'seabed' ? 'loading' : ''}
          `}
          onClick={() => onLayerChange('seabed')}
          disabled={isLoading}
        >
          <Mountain className="h-4 w-4" />
          <span>Seabed</span>
        </button>
      </div>

      {/* Info Text Below */}
      {activeLayer !== 'off' && (
        <div className="mt-2 px-1">
          <p className="text-xs opacity-60">
            {isLoading ? (
              'Loading layer...'
            ) : activeLayer === 'depth' ? (
              <>
                Bathymetry contours
                {dataSource === 'EBWBL' && ' • High resolution'}
              </>
            ) : (
              'Substrate composition'
            )}
          </p>
        </div>
      )}
    </div>
  );
};

// Mini version for the initial detail screen
export const LayerTeaser: React.FC<{
  onExpand: () => void;
}> = ({ onExpand }) => {
  return (
    <div className="flex items-center justify-between mt-2">
      {/* Disabled chips showing available layers */}
      <div className="flex gap-2">
        <div 
          className="badge badge-outline badge-sm gap-1 opacity-60 cursor-pointer"
          onClick={onExpand}
          title="Expand map to view depth layer"
        >
          <Waves className="h-3 w-3" />
          Depth
        </div>
        <div 
          className="badge badge-outline badge-sm gap-1 opacity-60 cursor-pointer"
          onClick={onExpand}
          title="Expand map to view seabed layer"
        >
          <Mountain className="h-3 w-3" />
          Seabed
        </div>
      </div>

      {/* Expand button */}
      <button
        onClick={onExpand}
        className="btn btn-primary btn-xs gap-1"
      >
        <Layers className="h-3 w-3" />
        View layers
      </button>
    </div>
  );
};

// Quality indicator badge
export const QualityIndicator: React.FC<{
  source: 'EBWBL' | 'EMODnet' | 'Cache' | null;
  isLoading?: boolean;
}> = ({ source, isLoading }) => {
  if (!source) return null;

  const getSourceInfo = () => {
    switch (source) {
      case 'EBWBL':
        return {
          label: 'HD',
          description: 'High-resolution bathymetry',
          color: 'badge-success'
        };
      case 'EMODnet':
        return {
          label: 'Standard',
          description: 'EMODnet bathymetry',
          color: 'badge-info'
        };
      case 'Cache':
        return {
          label: 'Offline',
          description: 'Cached data',
          color: 'badge-warning'
        };
      default:
        return null;
    }
  };

  const info = getSourceInfo();
  if (!info) return null;

  return (
    <div className="absolute top-16 right-4 z-[1000]">
      <div className={`badge ${info.color} badge-sm gap-1`}>
        {isLoading && <span className="loading loading-spinner loading-xs" />}
        <span className="font-medium">{info.label}</span>
      </div>
      <div className="text-xs opacity-60 mt-1 text-right">
        {info.description}
      </div>
    </div>
  );
};