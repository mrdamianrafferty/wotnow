# Findr EBWBL Map Feature - Complete Implementation Guide

## Project Overview

### Objective
Implement a sophisticated dual-tier bathymetry and substrate mapping system for the Findr fishing app, leveraging EMODnet's EBWBL (European Marine Observation and Data Network Bathymetry World Base Layer) as the primary high-resolution data source with intelligent fallbacks to standard EMODnet services.

### Business Requirements
- Display high-resolution bathymetric (depth) data for fishing spot analysis
- Show seabed substrate composition for understanding fish habitats
- Provide offline capability for previously viewed areas
- Optimize performance between mini and full-screen views
- Support mobile devices with touch gestures and safe area compliance

### Technical Stack
- **Framework**: Next.js 14+ with TypeScript
- **Map Library**: Leaflet 1.9.4
- **UI Components**: Tailwind CSS + DaisyUI
- **Icons**: Lucide React
- **State Management**: Zustand (for map state)
- **Caching**: Service Worker + IndexedDB
- **Analytics**: Custom event tracking

---

## Architecture Design

### Data Source Hierarchy

```
┌─────────────────────────────────────────────────┐
│                 User Request                     │
└────────────────────┬───────────────────────────┘
                     ▼
        ┌────────────────────────┐
        │   Is Full Screen?       │
        └────────┬───────┬────────┘
                Yes      No
                 │        │
                 ▼        ▼
        ┌──────────────┐  ┌──────────────┐
        │ Check EBWBL  │  │Use Standard  │
        │ Availability │  │  EMODnet     │
        └──────┬───────┘  └──────────────┘
               │
         Available?
         ┌─────┴─────┐
        Yes          No
         │            │
         ▼            ▼
    ┌─────────┐  ┌──────────┐
    │  EBWBL  │  │ Standard │
    │   WMTS  │  │ EMODnet  │
    └─────────┘  └────┬─────┘
                      │
                   Failed?
                      │
                      ▼
                ┌──────────┐
                │  Cache   │
                └──────────┘
```

### Service Endpoints

```yaml
EBWBL (Primary):
  type: WMTS
  url: https://tiles.emodnet-bathymetry.eu/2020/baselayer/{z}/{x}/{y}.png
  resolution: <100m
  coverage: Global with European enhancement
  format: PNG tiles
  projection: EPSG:3857 (Web Mercator)

Standard EMODnet Bathymetry (Fallback):
  type: WMS
  url: https://ows.emodnet-bathymetry.eu/wms
  layer: emodnet:mean_atlas_land
  resolution: ~115m (1/16 arc-minute)
  coverage: European seas
  format: PNG
  
EMODnet Geology (Substrate):
  type: WMS  
  url: https://ows.emodnet-geology.eu/geoserver/emodnet/wms
  layer: seabed_substrate_1m
  resolution: Variable
  coverage: European seas
  format: PNG

Base Map:
  type: Raster tiles
  url: https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png
  alternatives:
    - CartoDB Positron (lighter)
    - Stamen Terrain (topographic)
```

---

## File Structure

```
src/
├── components/
│   └── MapView/
│       ├── FullScreenMap.tsx       # Main full-screen map component
│       ├── MiniMap.tsx             # Compact map for detail views
│       ├── LayerControls.tsx       # Layer selection UI
│       ├── LegendDrawer.tsx        # Legend display component
│       ├── QualityIndicator.tsx    # Data source quality badge
│       ├── MapControls.tsx         # Zoom/GPS controls
│       └── MapErrorBoundary.tsx    # Error handling wrapper
│
├── hooks/
│   ├── useEBWBLLayer.ts           # EBWBL loading and fallback logic
│   ├── useMapState.ts             # Map state management
│   ├── useMapPreloader.ts         # Tile preloading logic
│   ├── useTileCache.ts            # Offline caching hook
│   └── useMapMetrics.ts           # Performance tracking
│
├── utils/
│   ├── mapServices.ts             # Service configuration
│   ├── tileCache.ts               # Tile caching utilities
│   ├── mapHelpers.ts              # Coordinate/tile calculations
│   ├── legendParser.ts            # Legend data processing
│   └── mapAnalytics.ts            # Analytics event helpers
│
├── config/
│   ├── map.config.ts              # Map configuration
│   ├── services.config.ts         # Service endpoints
│   └── cache.config.ts            # Cache settings
│
├── types/
│   ├── map.types.ts               # TypeScript definitions
│   └── services.types.ts          # Service type definitions
│
└── app/
    └── map/
        └── full/
            └── page.tsx            # Full-screen map route
```

---

## Implementation Details

### 1. Core Map Component (`FullScreenMap.tsx`)

```typescript
// Complete implementation structure
import React, { useEffect, useState, useCallback, useRef } from 'react';
import dynamic from 'next/dynamic';
import { useRouter, useSearchParams } from 'next/navigation';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';

// Type definitions
interface MapState {
  center: [number, number];
  zoom: number;
  layer: 'off' | 'depth' | 'seabed';
  quality: 'EBWBL' | 'EMODnet' | 'Cache' | null;
  bounds: L.LatLngBounds | null;
  lastUpdate: number;
}

interface LayerConfig {
  url: string;
  type: 'WMTS' | 'WMS';
  attribution: string;
  options: L.TileLayerOptions | L.WMSOptions;
}

// Component implementation
export const FullScreenMap: React.FC = () => {
  // URL parameter parsing
  const searchParams = useSearchParams();
  const initialState: MapState = {
    center: [
      parseFloat(searchParams.get('lat') || '43.5'),
      parseFloat(searchParams.get('lon') || '-6.0')
    ],
    zoom: parseInt(searchParams.get('z') || '12'),
    layer: (searchParams.get('layer') as MapState['layer']) || 'off',
    quality: null,
    bounds: null,
    lastUpdate: Date.now()
  };

  // State management
  const [mapState, setMapState] = useState<MapState>(initialState);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  // Refs
  const mapContainer = useRef<HTMLDivElement>(null);
  const mapInstance = useRef<L.Map | null>(null);
  const currentLayers = useRef<Map<string, L.Layer>>(new Map());

  // Initialize map
  useEffect(() => {
    if (!mapContainer.current || mapInstance.current) return;

    // Create map instance
    const map = L.map(mapContainer.current, {
      center: mapState.center,
      zoom: mapState.zoom,
      zoomControl: false,
      attributionControl: false,
      maxBounds: [[-90, -180], [90, 180]],
      minZoom: 2,
      maxZoom: 18,
      preferCanvas: true // Better performance for many markers
    });

    // Add base layer
    const baseLayer = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '© OpenStreetMap contributors',
      maxZoom: 19,
      crossOrigin: 'anonymous'
    });
    baseLayer.addTo(map);

    // Store reference
    mapInstance.current = map;

    // Event listeners
    map.on('moveend', handleMapMove);
    map.on('zoomend', handleZoomChange);
    map.on('click', handleMapClick);

    // Cleanup
    return () => {
      map.off();
      map.remove();
      mapInstance.current = null;
    };
  }, []);

  // Layer management functions
  const loadEBWBLLayer = async (): Promise<boolean> => {
    // Implementation here
    return true;
  };

  const loadStandardLayer = async (type: 'bathymetry' | 'substrate'): Promise<boolean> => {
    // Implementation here
    return true;
  };

  const clearLayers = () => {
    // Implementation here
  };

  // Event handlers
  const handleMapMove = () => {
    // Update state and URL
  };

  const handleZoomChange = () => {
    // Check if we need to switch quality
  };

  const handleMapClick = (e: L.LeafletMouseEvent) => {
    // Handle map interactions
  };

  // Render
  return (
    <div className="fixed inset-0 z-[9999] flex flex-col h-[100svh]">
      {/* Implementation */}
    </div>
  );
};
```

### 2. EBWBL Layer Hook (`useEBWBLLayer.ts`)

```typescript
// Detailed hook implementation
import { useState, useCallback, useRef } from 'react';
import L from 'leaflet';

interface EBWBLConfig {
  baseUrl: string;
  testTile: { z: number; x: number; y: number };
  timeout: number;
  retryAttempts: number;
  retryDelay: number;
}

const DEFAULT_CONFIG: EBWBLConfig = {
  baseUrl: 'https://tiles.emodnet-bathymetry.eu/2020/baselayer',
  testTile: { z: 4, x: 8, y: 5 },
  timeout: 5000,
  retryAttempts: 3,
  retryDelay: 1000
};

export const useEBWBLLayer = (config: Partial<EBWBLConfig> = {}) => {
  const finalConfig = { ...DEFAULT_CONFIG, ...config };
  const [status, setStatus] = useState<'idle' | 'loading' | 'success' | 'error'>('idle');
  const [quality, setQuality] = useState<'EBWBL' | 'EMODnet' | null>(null);
  const activeLayer = useRef<L.Layer | null>(null);

  // Test EBWBL availability with retry logic
  const testAvailability = useCallback(async (): Promise<boolean> => {
    let attempts = 0;
    
    while (attempts < finalConfig.retryAttempts) {
      try {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), finalConfig.timeout);
        
        const testUrl = `${finalConfig.baseUrl}/${finalConfig.testTile.z}/${finalConfig.testTile.x}/${finalConfig.testTile.y}.png`;
        
        const response = await fetch(testUrl, {
          method: 'HEAD',
          signal: controller.signal,
          mode: 'cors',
          cache: 'no-cache'
        });
        
        clearTimeout(timeoutId);
        
        if (response.ok) {
          return true;
        }
      } catch (error) {
        console.warn(`EBWBL test attempt ${attempts + 1} failed:`, error);
      }
      
      attempts++;
      if (attempts < finalConfig.retryAttempts) {
        await new Promise(resolve => setTimeout(resolve, finalConfig.retryDelay));
      }
    }
    
    return false;
  }, [finalConfig]);

  // Load EBWBL tiles
  const loadEBWBL = useCallback(async (map: L.Map): Promise<boolean> => {
    setStatus('loading');
    
    try {
      const isAvailable = await testAvailability();
      
      if (!isAvailable) {
        setStatus('error');
        return false;
      }

      // Remove existing layer
      if (activeLayer.current) {
        map.removeLayer(activeLayer.current);
      }

      // Create EBWBL layer
      const ebwblLayer = L.tileLayer(`${finalConfig.baseUrl}/{z}/{x}/{y}.png`, {
        attribution: '© EMODnet Bathymetry Consortium (EBWBL)',
        maxZoom: 14,
        minZoom: 2,
        opacity: 0.8,
        className: 'ebwbl-tiles',
        crossOrigin: 'anonymous',
        errorTileUrl: 'data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7'
      });

      // Track tile loading
      let tilesLoaded = 0;
      let tilesFailed = 0;
      
      ebwblLayer.on('tileload', () => {
        tilesLoaded++;
      });
      
      ebwblLayer.on('tileerror', () => {
        tilesFailed++;
        if (tilesFailed > 5) {
          console.warn('Too many EBWBL tile failures, consider fallback');
        }
      });

      ebwblLayer.addTo(map);
      activeLayer.current = ebwblLayer;
      
      setQuality('EBWBL');
      setStatus('success');
      
      return true;
    } catch (error) {
      console.error('Failed to load EBWBL:', error);
      setStatus('error');
      return false;
    }
  }, [finalConfig, testAvailability]);

  // Fallback to standard EMODnet
  const loadStandard = useCallback(async (
    map: L.Map, 
    type: 'bathymetry' | 'substrate'
  ): Promise<boolean> => {
    setStatus('loading');
    
    try {
      // Remove existing layer
      if (activeLayer.current) {
        map.removeLayer(activeLayer.current);
      }

      const configs = {
        bathymetry: {
          url: 'https://ows.emodnet-bathymetry.eu/wms',
          layers: 'emodnet:mean_atlas_land',
          format: 'image/png',
          attribution: '© EMODnet Bathymetry Consortium'
        },
        substrate: {
          url: 'https://ows.emodnet-geology.eu/geoserver/emodnet/wms',
          layers: 'seabed_substrate_1m',
          format: 'image/png',
          attribution: '© EMODnet Geology'
        }
      };

      const config = configs[type];
      
      const wmsLayer = L.tileLayer.wms(config.url, {
        layers: config.layers,
        format: config.format,
        transparent: true,
        attribution: config.attribution,
        opacity: 0.7,
        version: '1.3.0',
        crs: L.CRS.EPSG3857
      });

      wmsLayer.addTo(map);
      activeLayer.current = wmsLayer;
      
      setQuality('EMODnet');
      setStatus('success');
      
      return true;
    } catch (error) {
      console.error('Failed to load standard layer:', error);
      setStatus('error');
      return false;
    }
  }, []);

  // Clear all layers
  const clearLayers = useCallback((map: L.Map) => {
    if (activeLayer.current) {
      map.removeLayer(activeLayer.current);
      activeLayer.current = null;
    }
    setQuality(null);
    setStatus('idle');
  }, []);

  return {
    loadEBWBL,
    loadStandard,
    clearLayers,
    status,
    quality,
    testAvailability
  };
};
```

### 3. Map State Management (`useMapState.ts`)

```typescript
import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';

interface MapStore {
  // State
  center: [number, number];
  zoom: number;
  layer: 'off' | 'depth' | 'seabed';
  quality: 'EBWBL' | 'EMODnet' | 'Cache' | null;
  bounds: { north: number; south: number; east: number; west: number } | null;
  favorites: Array<{ id: string; name: string; center: [number, number] }>;
  recentViews: Array<{ timestamp: number; center: [number, number]; zoom: number }>;
  
  // Actions
  updateCenter: (center: [number, number]) => void;
  updateZoom: (zoom: number) => void;
  setLayer: (layer: MapStore['layer']) => void;
  setQuality: (quality: MapStore['quality']) => void;
  setBounds: (bounds: MapStore['bounds']) => void;
  addFavorite: (favorite: MapStore['favorites'][0]) => void;
  removeFavorite: (id: string) => void;
  addRecentView: () => void;
  clearRecentViews: () => void;
  
  // Computed
  getStateForURL: () => URLSearchParams;
  loadFromURL: (params: URLSearchParams) => void;
}

export const useMapStore = create<MapStore>()(
  persist(
    (set, get) => ({
      // Initial state
      center: [43.5, -6.0], // Asturias default
      zoom: 12,
      layer: 'off',
      quality: null,
      bounds: null,
      favorites: [],
      recentViews: [],

      // Actions implementation
      updateCenter: (center) => set({ center }),
      updateZoom: (zoom) => set({ zoom }),
      setLayer: (layer) => set({ layer }),
      setQuality: (quality) => set({ quality }),
      setBounds: (bounds) => set({ bounds }),
      
      addFavorite: (favorite) => set((state) => ({
        favorites: [...state.favorites, favorite].slice(-10) // Keep last 10
      })),
      
      removeFavorite: (id) => set((state) => ({
        favorites: state.favorites.filter(f => f.id !== id)
      })),
      
      addRecentView: () => set((state) => ({
        recentViews: [
          {
            timestamp: Date.now(),
            center: state.center,
            zoom: state.zoom
          },
          ...state.recentViews
        ].slice(0, 20) // Keep last 20 views
      })),
      
      clearRecentViews: () => set({ recentViews: [] }),
      
      // URL state management
      getStateForURL: () => {
        const state = get();
        const params = new URLSearchParams();
        params.set('lat', state.center[0].toString());
        params.set('lon', state.center[1].toString());
        params.set('z', state.zoom.toString());
        if (state.layer !== 'off') {
          params.set('layer', state.layer);
        }
        return params;
      },
      
      loadFromURL: (params) => {
        const lat = parseFloat(params.get('lat') || '43.5');
        const lon = parseFloat(params.get('lon') || '-6.0');
        const zoom = parseInt(params.get('z') || '12');
        const layer = (params.get('layer') || 'off') as MapStore['layer'];
        
        set({
          center: [lat, lon],
          zoom,
          layer
        });
      }
    }),
    {
      name: 'findr-map-state',
      storage: createJSONStorage(() => localStorage),
      partialize: (state) => ({
        favorites: state.favorites,
        recentViews: state.recentViews
      })
    }
  )
);
```

### 4. Tile Caching System (`tileCache.ts`)

```typescript
interface CacheConfig {
  name: string;
  version: number;
  maxAge: number;
  maxSize: number;
  cleanupInterval: number;
}

class TileCache {
  private config: CacheConfig;
  private cache: Cache | null = null;
  private db: IDBDatabase | null = null;
  
  constructor(config: Partial<CacheConfig> = {}) {
    this.config = {
      name: 'findr-map-tiles',
      version: 1,
      maxAge: 7 * 24 * 60 * 60 * 1000, // 7 days
      maxSize: 100 * 1024 * 1024, // 100MB
      cleanupInterval: 60 * 60 * 1000, // 1 hour
      ...config
    };
    
    this.initialize();
  }

  private async initialize() {
    // Initialize Cache API
    if ('caches' in window) {
      this.cache = await caches.open(`${this.config.name}-v${this.config.version}`);
    }
    
    // Initialize IndexedDB for metadata
    const request = indexedDB.open(`${this.config.name}-meta`, this.config.version);
    
    request.onsuccess = () => {
      this.db = request.result;
      this.scheduleCleanup();
    };
    
    request.onupgradeneeded = (event) => {
      const db = (event.target as IDBOpenDBRequest).result;
      
      if (!db.objectStoreNames.contains('tiles')) {
        const store = db.createObjectStore('tiles', { keyPath: 'url' });
        store.createIndex('timestamp', 'timestamp');
        store.createIndex('size', 'size');
      }
    };
  }

  async get(url: string): Promise<Response | null> {
    if (!this.cache) return null;
    
    const cached = await this.cache.match(url);
    
    if (cached) {
      // Update access time in IndexedDB
      this.updateAccessTime(url);
      return cached;
    }
    
    return null;
  }

  async put(url: string, response: Response): Promise<void> {
    if (!this.cache || !this.db) return;
    
    // Clone response for caching
    const responseToCache = response.clone();
    const blob = await responseToCache.blob();
    
    // Check if we need to make space
    await this.ensureSpace(blob.size);
    
    // Cache the response
    await this.cache.put(url, responseToCache);
    
    // Store metadata
    const transaction = this.db.transaction(['tiles'], 'readwrite');
    const store = transaction.objectStore('tiles');
    
    store.put({
      url,
      timestamp: Date.now(),
      size: blob.size,
      type: blob.type
    });
  }

  private async ensureSpace(requiredSize: number): Promise<void> {
    if (!this.db) return;
    
    const transaction = this.db.transaction(['tiles'], 'readonly');
    const store = transaction.objectStore('tiles');
    const request = store.getAll();
    
    return new Promise((resolve) => {
      request.onsuccess = async () => {
        const tiles = request.result;
        let totalSize = tiles.reduce((sum, tile) => sum + tile.size, 0);
        
        if (totalSize + requiredSize > this.config.maxSize) {
          // Remove oldest tiles until we have space
          tiles.sort((a, b) => a.timestamp - b.timestamp);
          
          for (const tile of tiles) {
            if (totalSize + requiredSize <= this.config.maxSize) break;
            
            await this.remove(tile.url);
            totalSize -= tile.size;
          }
        }
        
        resolve();
      };
    });
  }

  private async remove(url: string): Promise<void> {
    if (this.cache) {
      await this.cache.delete(url);
    }
    
    if (this.db) {
      const transaction = this.db.transaction(['tiles'], 'readwrite');
      const store = transaction.objectStore('tiles');
      store.delete(url);
    }
  }

  private async updateAccessTime(url: string): Promise<void> {
    if (!this.db) return;
    
    const transaction = this.db.transaction(['tiles'], 'readwrite');
    const store = transaction.objectStore('tiles');
    const request = store.get(url);
    
    request.onsuccess = () => {
      const tile = request.result;
      if (tile) {
        tile.timestamp = Date.now();
        store.put(tile);
      }
    };
  }

  private scheduleCleanup() {
    setInterval(async () => {
      await this.cleanup();
    }, this.config.cleanupInterval);
  }

  private async cleanup(): Promise<void> {
    if (!this.db) return;
    
    const transaction = this.db.transaction(['tiles'], 'readonly');
    const store = transaction.objectStore('tiles');
    const request = store.getAll();
    
    request.onsuccess = async () => {
      const tiles = request.result;
      const now = Date.now();
      
      for (const tile of tiles) {
        if (now - tile.timestamp > this.config.maxAge) {
          await this.remove(tile.url);
        }
      }
    };
  }

  async preloadArea(bounds: L.LatLngBounds, zoom: number, source: string): Promise<void> {
    const tiles = this.calculateTilesInBounds(bounds, zoom);
    
    // Preload in batches
    const batchSize = 4;
    for (let i = 0; i < tiles.length; i += batchSize) {
      const batch = tiles.slice(i, i + batchSize);
      
      await Promise.all(
        batch.map(tile => this.preloadTile(tile, source))
      );
      
      // Small delay between batches
      await new Promise(resolve => setTimeout(resolve, 100));
    }
  }

  private calculateTilesInBounds(
    bounds: L.LatLngBounds,
    zoom: number
  ): Array<{ x: number; y: number; z: number }> {
    const tiles: Array<{ x: number; y: number; z: number }> = [];
    
    const nw = bounds.getNorthWest();
    const se = bounds.getSouthEast();
    
    const nwTile = this.latLngToTile(nw.lat, nw.lng, zoom);
    const seTile = this.latLngToTile(se.lat, se.lng, zoom);
    
    for (let x = nwTile.x; x <= seTile.x; x++) {
      for (let y = nwTile.y; y <= seTile.y; y++) {
        tiles.push({ x, y, z: zoom });
      }
    }
    
    return tiles;
  }

  private latLngToTile(lat: number, lng: number, zoom: number) {
    const x = Math.floor((lng + 180) / 360 * Math.pow(2, zoom));
    const y = Math.floor((1 - Math.log(
      Math.tan(lat * Math.PI / 180) + 1 / Math.cos(lat * Math.PI / 180)
    ) / Math.PI) / 2 * Math.pow(2, zoom));
    
    return { x, y };
  }

  private async preloadTile(
    tile: { x: number; y: number; z: number },
    source: string
  ): Promise<void> {
    const url = this.getTileUrl(tile, source);
    
    // Check if already cached
    const cached = await this.get(url);
    if (cached) return;
    
    try {
      const response = await fetch(url, {
        mode: 'cors',
        cache: 'force-cache'
      });
      
      if (response.ok) {
        await this.put(url, response);
      }
    } catch (error) {
      // Silent fail for preloading
    }
  }

  private getTileUrl(tile: { x: number; y: number; z: number }, source: string): string {
    if (source === 'EBWBL') {
      return `https://tiles.emodnet-bathymetry.eu/2020/baselayer/${tile.z}/${tile.x}/${tile.y}.png`;
    } else {
      // Standard EMODnet or other sources
      return `https://ows.emodnet-bathymetry.eu/wms?SERVICE=WMS&VERSION=1.3.0&REQUEST=GetMap&LAYERS=emodnet:mean_atlas_land&BBOX=${this.tileToBBox(tile)}&WIDTH=256&HEIGHT=256&CRS=EPSG:3857&FORMAT=image/png`;
    }
  }

  private tileToBBox(tile: { x: number; y: number; z: number }): string {
    const n = Math.pow(2, tile.z);
    const lon1 = (tile.x / n) * 360 - 180;
    const lat1 = Math.atan(Math.sinh(Math.PI * (1 - 2 * tile.y / n))) * 180 / Math.PI;
    const lon2 = ((tile.x + 1) / n) * 360 - 180;
    const lat2 = Math.atan(Math.sinh(Math.PI * (1 - 2 * (tile.y + 1) / n))) * 180 / Math.PI;
    
    // Convert to Web Mercator
    const bounds = this.latLngToBounds(lat1, lon1, lat2, lon2);
    return `${bounds.minX},${bounds.minY},${bounds.maxX},${bounds.maxY}`;
  }

  private latLngToBounds(lat1: number, lon1: number, lat2: number, lon2: number) {
    // Web Mercator projection
    const minX = lon1 * 20037508.34 / 180;
    const maxX = lon2 * 20037508.34 / 180;
    const minY = Math.log(Math.tan((90 + lat2) * Math.PI / 360)) / (Math.PI / 180) * 20037508.34 / 180;
    const maxY = Math.log(Math.tan((90 + lat1) * Math.PI / 360)) / (Math.PI / 180) * 20037508.34 / 180;
    
    return { minX, minY, maxX, maxY };
  }

  // Analytics
  async getStats(): Promise<{
    totalTiles: number;
    totalSize: number;
    oldestTile: number;
    newestTile: number;
    hitRate: number;
  }> {
    if (!this.db) {
      return {
        totalTiles: 0,
        totalSize: 0,
        oldestTile: 0,
        newestTile: 0,
        hitRate: 0
      };
    }
    
    return new Promise((resolve) => {
      const transaction = this.db!.transaction(['tiles'], 'readonly');
      const store = transaction.objectStore('tiles');
      const request = store.getAll();
      
      request.onsuccess = () => {
        const tiles = request.result;
        
        if (tiles.length === 0) {
          resolve({
            totalTiles: 0,
            totalSize: 0,
            oldestTile: 0,
            newestTile: 0,
            hitRate: 0
          });
          return;
        }
        
        const stats = {
          totalTiles: tiles.length,
          totalSize: tiles.reduce((sum, tile) => sum + tile.size, 0),
          oldestTile: Math.min(...tiles.map(t => t.timestamp)),
          newestTile: Math.max(...tiles.map(t => t.timestamp)),
          hitRate: 0 // This would need separate tracking
        };
        
        resolve(stats);
      };
    });
  }
}

// Export singleton instance
export const tileCache = new TileCache();
```

### 5. Service Worker (`sw.js`)

```javascript
// Service worker for offline support and performance
const CACHE_VERSION = 'findr-maps-v1';
const TILE_CACHE = 'findr-tiles-v1';

// URLs to cache for offline use
const STATIC_CACHE = [
  '/map/full',
  '/assets/map-styles.css',
  '/assets/map-icons.svg'
];

// Install event
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_VERSION).then((cache) => {
      return cache.addAll(STATIC_CACHE);
    })
  );
});

// Activate event
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames
          .filter((name) => name !== CACHE_VERSION && name !== TILE_CACHE)
          .map((name) => caches.delete(name))
      );
    })
  );
});

// Fetch event
self.addEventListener('fetch', (event) => {
  const url = new URL(event.request.url);
  
  // Handle tile requests
  if (url.hostname.includes('emodnet') || url.hostname.includes('openstreetmap')) {
    event.respondWith(
      caches.open(TILE_CACHE).then((cache) => {
        return cache.match(event.request).then((response) => {
          if (response) {
            // Return cached tile
            return response;
          }
          
          // Fetch and cache new tile
          return fetch(event.request).then((response) => {
            // Only cache successful responses
            if (response.status === 200) {
              cache.put(event.request, response.clone());
            }
            return response;
          }).catch(() => {
            // Return fallback tile if offline
            return new Response(createFallbackTile(), {
              headers: { 'Content-Type': 'image/png' }
            });
          });
        });
      })
    );
    return;
  }
  
  // Handle other requests
  event.respondWith(
    caches.match(event.request).then((response) => {
      return response || fetch(event.request);
    })
  );
});

// Create a fallback tile (transparent PNG)
function createFallbackTile() {
  const canvas = new OffscreenCanvas(256, 256);
  const ctx = canvas.getContext('2d');
  
  // Draw a subtle pattern to indicate offline
  ctx.fillStyle = 'rgba(200, 200, 200, 0.3)';
  ctx.fillRect(0, 0, 256, 256);
  
  ctx.strokeStyle = 'rgba(150, 150, 150, 0.5)';
  ctx.lineWidth = 1;
  ctx.setLineDash([5, 5]);
  ctx.strokeRect(0, 0, 256, 256);
  
  return canvas.convertToBlob({ type: 'image/png' });
}

// Background sync for preloading
self.addEventListener('sync', (event) => {
  if (event.tag === 'preload-tiles') {
    event.waitUntil(preloadCommonAreas());
  }
});

async function preloadCommonAreas() {
  // Preload common fishing spots
  const commonAreas = [
    { lat: 43.5, lon: -6.0, zoom: 12 }, // Asturias coast
    // Add more common areas
  ];
  
  for (const area of commonAreas) {
    await preloadArea(area.lat, area.lon, area.zoom);
  }
}

async function preloadArea(lat, lon, zoom) {
  // Calculate tile URLs for the area
  const tiles = calculateTiles(lat, lon, zoom);
  
  const cache = await caches.open(TILE_CACHE);
  
  for (const tileUrl of tiles) {
    try {
      const response = await fetch(tileUrl);
      if (response.ok) {
        await cache.put(tileUrl, response);
      }
    } catch (error) {
      // Silent fail for preloading
    }
  }
}

function calculateTiles(lat, lon, zoom) {
  // Calculate 9 tiles around the center point
  const tiles = [];
  const centerTile = latLonToTile(lat, lon, zoom);
  
  for (let dx = -1; dx <= 1; dx++) {
    for (let dy = -1; dy <= 1; dy++) {
      const x = centerTile.x + dx;
      const y = centerTile.y + dy;
      
      tiles.push(
        `https://tiles.emodnet-bathymetry.eu/2020/baselayer/${zoom}/${x}/${y}.png`
      );
    }
  }
  
  return tiles;
}

function latLonToTile(lat, lon, zoom) {
  const x = Math.floor((lon + 180) / 360 * Math.pow(2, zoom));
  const y = Math.floor((1 - Math.log(
    Math.tan(lat * Math.PI / 180) + 1 / Math.cos(lat * Math.PI / 180)
  ) / Math.PI) / 2 * Math.pow(2, zoom));
  
  return { x, y };
}
```

---

## Testing Procedures

### 1. Unit Tests

```typescript
// Example test file: useEBWBLLayer.test.ts
import { renderHook, act } from '@testing-library/react-hooks';
import { useEBWBLLayer } from '../hooks/useEBWBLLayer';
import L from 'leaflet';

describe('useEBWBLLayer', () => {
  let map: L.Map;
  
  beforeEach(() => {
    // Create mock map
    const container = document.createElement('div');
    map = L.map(container);
  });
  
  afterEach(() => {
    map.remove();
  });
  
  test('should test EBWBL availability', async () => {
    const { result } = renderHook(() => useEBWBLLayer());
    
    let isAvailable: boolean;
    await act(async () => {
      isAvailable = await result.current.testAvailability();
    });
    
    expect(typeof isAvailable).toBe('boolean');
  });
  
  test('should fallback to standard when EBWBL fails', async () => {
    // Mock fetch to fail for EBWBL
    global.fetch = jest.fn()
      .mockRejectedValueOnce(new Error('Network error'))
      .mockResolvedValueOnce({
        ok: true,
        headers: new Headers()
      });
    
    const { result } = renderHook(() => useEBWBLLayer());
    
    await act(async () => {
      const success = await result.current.loadEBWBL(map);
      expect(success).toBe(false);
    });
    
    await act(async () => {
      const success = await result.current.loadStandard(map, 'bathymetry');
      expect(success).toBe(true);
    });
    
    expect(result.current.quality).toBe('EMODnet');
  });
  
  test('should handle tile loading errors gracefully', async () => {
    // Test implementation
  });
});
```

### 2. Integration Tests

```typescript
// Integration test example
import { render, screen, waitFor, fireEvent } from '@testing-library/react';
import { FullScreenMap } from '../components/MapView/FullScreenMap';

describe('FullScreenMap Integration', () => {
  test('should load EBWBL layer when available', async () => {
    render(<FullScreenMap />);
    
    // Click depth button
    const depthButton = screen.getByRole('button', { name: /depth/i });
    fireEvent.click(depthButton);
    
    // Wait for layer to load
    await waitFor(() => {
      expect(screen.getByText(/HD/i)).toBeInTheDocument();
    }, { timeout: 5000 });
  });
  
  test('should show offline indicator when no network', async () => {
    // Simulate offline
    Object.defineProperty(navigator, 'onLine', {
      writable: true,
      value: false
    });
    
    render(<FullScreenMap />);
    
    const depthButton = screen.getByRole('button', { name: /depth/i });
    fireEvent.click(depthButton);
    
    await waitFor(() => {
      expect(screen.getByText(/offline/i)).toBeInTheDocument();
    });
  });
});
```

### 3. E2E Tests

```typescript
// Cypress E2E test
describe('Map Feature E2E', () => {
  beforeEach(() => {
    cy.visit('/map/full?lat=43.5&lon=-6.0&z=12');
  });
  
  it('should load full-screen map with controls', () => {
    cy.get('[data-testid="map-container"]').should('be.visible');
    cy.get('[data-testid="layer-controls"]').should('be.visible');
    cy.get('[data-testid="zoom-controls"]').should('be.visible');
  });
  
  it('should switch between layers', () => {
    // Test depth layer
    cy.get('[data-testid="depth-button"]').click();
    cy.get('[data-testid="loading-indicator"]').should('be.visible');
    cy.get('[data-testid="quality-badge"]', { timeout: 10000 }).should('contain', 'HD');
    
    // Test seabed layer
    cy.get('[data-testid="seabed-button"]').click();
    cy.get('[data-testid="loading-indicator"]').should('be.visible');
    cy.get('[data-testid="quality-badge"]', { timeout: 10000 }).should('contain', 'Standard');
    
    // Test off
    cy.get('[data-testid="off-button"]').click();
    cy.get('[data-testid="quality-badge"]').should('not.exist');
  });
  
  it('should handle zoom controls', () => {
    cy.get('[data-testid="zoom-in"]').click();
    cy.url().should('include', 'z=13');
    
    cy.get('[data-testid="zoom-out"]').click();
    cy.url().should('include', 'z=12');
  });
  
  it('should persist state in URL', () => {
    cy.get('[data-testid="depth-button"]').click();
    cy.url().should('include', 'layer=depth');
    
    cy.reload();
    cy.get('[data-testid="depth-button"]').should('have.class', 'btn-active');
  });
});
```

---

## Deployment Checklist

### Environment Setup

```bash
# 1. Install dependencies
npm install leaflet@^1.9.4
npm install react-leaflet@^4.2.1
npm install lucide-react@^0.263.1
npm install zustand@^4.4.1
npm install -D @types/leaflet

# 2. Environment variables (.env.local)
NEXT_PUBLIC_ENABLE_EBWBL=true
NEXT_PUBLIC_EBWBL_ENDPOINT=https://tiles.emodnet-bathymetry.eu/2020/baselayer
NEXT_PUBLIC_EMODNET_BATH_ENDPOINT=https://ows.emodnet-bathymetry.eu/wms
NEXT_PUBLIC_EMODNET_GEO_ENDPOINT=https://ows.emodnet-geology.eu/geoserver/emodnet/wms
NEXT_PUBLIC_TILE_CACHE_ENABLED=true
NEXT_PUBLIC_TILE_CACHE_SIZE_MB=100
NEXT_PUBLIC_TILE_CACHE_TTL_DAYS=7

# 3. Configure Next.js
```

### Next.js Configuration

```javascript
// next.config.js
module.exports = {
  images: {
    domains: [
      'tiles.emodnet-bathymetry.eu',
      'ows.emodnet-bathymetry.eu',
      'ows.emodnet-geology.eu',
      'tile.openstreetmap.org'
    ]
  },
  
  async headers() {
    return [
      {
        source: '/map/:path*',
        headers: [
          {
            key: 'Cache-Control',
            value: 'public, max-age=31536000, immutable'
          }
        ]
      }
    ];
  },
  
  async rewrites() {
    return [
      {
        source: '/api/tiles/:path*',
        destination: 'https://tiles.emodnet-bathymetry.eu/:path*'
      }
    ];
  }
};
```

### Build and Deploy

```bash
# Build checks
npm run type-check
npm run lint
npm run test
npm run test:e2e

# Production build
npm run build

# Analyze bundle
npm run analyze

# Deploy to Vercel
vercel --prod
```

### Performance Monitoring

```typescript
// Analytics implementation
export const trackMapEvent = (event: string, properties: Record<string, any>) => {
  // Send to analytics service
  if (window.gtag) {
    window.gtag('event', event, properties);
  }
  
  // Send to custom metrics endpoint
  fetch('/api/metrics', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      event,
      properties,
      timestamp: Date.now(),
      viewport: {
        width: window.innerWidth,
        height: window.innerHeight
      },
      connection: (navigator as any).connection?.effectiveType
    })
  });
};

// Usage
trackMapEvent('layer_loaded', {
  layer: 'depth',
  source: 'EBWBL',
  loadTime: 1234,
  tileCount: 9,
  cacheHit: false
});
```

---

## Troubleshooting Guide

### Common Issues and Solutions

#### 1. EBWBL Tiles Not Loading

**Symptoms:**
- HD badge doesn't appear
- Fallback to standard immediately

**Solutions:**
```typescript
// Check CORS headers
fetch('https://tiles.emodnet-bathymetry.eu/2020/baselayer/4/8/5.png', {
  mode: 'cors'
}).then(response => {
  console.log('CORS enabled:', response.ok);
  console.log('Headers:', response.headers);
});

// Verify network connectivity
navigator.connection?.addEventListener('change', () => {
  console.log('Network changed:', navigator.connection.effectiveType);
});

// Test with direct tile URL
const testTile = new Image();
testTile.crossOrigin = 'anonymous';
testTile.onload = () => console.log('Tile loaded successfully');
testTile.onerror = () => console.log('Tile failed to load');
testTile.src = 'https://tiles.emodnet-bathymetry.eu/2020/baselayer/4/8/5.png';
```

#### 2. Performance Issues

**Symptoms:**
- Slow tile loading
- Map stuttering on pan/zoom

**Solutions:**
```typescript
// Optimize tile loading
const optimizedLayer = L.tileLayer(url, {
  maxZoom: 14,
  maxNativeZoom: 12, // Don't overzoom
  detectRetina: false, // Disable on slow devices
  updateWhenIdle: true, // Update only when idle
  updateWhenZooming: false, // Don't update during zoom
  keepBuffer: 2, // Tile buffer size
  tileSize: 256,
  subdomains: ['a', 'b', 'c'] // Use subdomains for parallel loading
});

// Implement request throttling
class TileLoader {
  private queue: Array<() => Promise<void>> = [];
  private active = 0;
  private maxConcurrent = 4;
  
  async load(url: string): Promise<Response> {
    return new Promise((resolve, reject) => {
      this.queue.push(async () => {
        this.active++;
        try {
          const response = await fetch(url);
          resolve(response);
        } catch (error) {
          reject(error);
        } finally {
          this.active--;
          this.processQueue();
        }
      });
      
      this.processQueue();
    });
  }
  
  private processQueue() {
    while (this.active < this.maxConcurrent && this.queue.length > 0) {
      const task = this.queue.shift();
      task?.();
    }
  }
}
```

#### 3. Cache Issues

**Symptoms:**
- Old tiles showing
- Cache not updating

**Solutions:**
```typescript
// Clear cache
async function clearTileCache() {
  if ('caches' in window) {
    const names = await caches.keys();
    await Promise.all(
      names.map(name => caches.delete(name))
    );
  }
  
  // Clear IndexedDB
  const dbs = await indexedDB.databases();
  await Promise.all(
    dbs.map(db => {
      if (db.name?.includes('tile')) {
        return indexedDB.deleteDatabase(db.name);
      }
    })
  );
  
  console.log('Cache cleared');
}

// Force refresh tiles
const layer = L.tileLayer(url, {
  maxAge: 0, // Don't use browser cache
  cache: 'reload' // Force reload
});
```

#### 4. Mobile-Specific Issues

**Symptoms:**
- Touch gestures not working
- Safe area problems on iOS

**Solutions:**
```css
/* CSS fixes for mobile */
.map-container {
  height: 100vh;
  height: 100svh; /* Small viewport height */
  padding-top: env(safe-area-inset-top);
  padding-bottom: env(safe-area-inset-bottom);
  padding-left: env(safe-area-inset-left);
  padding-right: env(safe-area-inset-right);
}

/* Prevent iOS bounce */
.map-container {
  position: fixed;
  overflow: hidden;
  -webkit-overflow-scrolling: auto;
}

/* Fix for iOS Safari address bar */
.fullscreen-map {
  min-height: -webkit-fill-available;
}
```

```typescript
// JavaScript fixes
// Handle iOS viewport changes
let vh = window.innerHeight * 0.01;
document.documentElement.style.setProperty('--vh', `${vh}px`);

window.addEventListener('resize', () => {
  vh = window.innerHeight * 0.01;
  document.documentElement.style.setProperty('--vh', `${vh}px`);
});

// Prevent iOS bounce
document.addEventListener('touchmove', (e) => {
  if (e.target.closest('.map-container')) {
    e.preventDefault();
  }
}, { passive: false });
```

---

## Security Considerations

### Content Security Policy

```typescript
// CSP headers for map resources
export const mapCSP = {
  'default-src': ["'self'"],
  'script-src': ["'self'", "'unsafe-inline'", "'unsafe-eval'"], // Required for Leaflet
  'style-src': ["'self'", "'unsafe-inline'"],
  'img-src': [
    "'self'",
    'data:',
    'blob:',
    'https://*.emodnet-bathymetry.eu',
    'https://*.openstreetmap.org',
    'https://*.tile.openstreetmap.org'
  ],
  'connect-src': [
    "'self'",
    'https://*.emodnet-bathymetry.eu',
    'https://*.emodnet-geology.eu',
    'https://*.openstreetmap.org'
  ],
  'worker-src': ["'self'", 'blob:']
};
```

### API Key Management

```typescript
// Secure API key handling (if required)
class SecureMapService {
  private apiKey: string | null = null;
  
  async initialize() {
    // Fetch API key from secure endpoint
    const response = await fetch('/api/map-config', {
      credentials: 'include'
    });
    
    const config = await response.json();
    this.apiKey = config.apiKey;
  }
  
  getTileUrl(tile: { x: number; y: number; z: number }): string {
    const baseUrl = process.env.NEXT_PUBLIC_TILE_ENDPOINT;
    
    if (this.apiKey) {
      return `${baseUrl}/${tile.z}/${tile.x}/${tile.y}.png?key=${this.apiKey}`;
    }
    
    return `${baseUrl}/${tile.z}/${tile.x}/${tile.y}.png`;
  }
}
```

---

## Performance Metrics

### Target Metrics

| Metric | Target | Measurement Method |
|--------|--------|-------------------|
| Initial Load | <2s | Performance.timing |
| Tile Load | <500ms | Resource Timing API |
| Layer Switch | <1s | Custom timer |
| Cache Hit Rate | >60% | IndexedDB stats |
| Memory Usage | <100MB | Performance.memory |
| Frame Rate | 60fps | requestAnimationFrame |

### Monitoring Implementation

```typescript
class MapPerformanceMonitor {
  private metrics: Map<string, number[]> = new Map();
  
  startTimer(name: string): () => void {
    const start = performance.now();
    
    return () => {
      const duration = performance.now() - start;
      this.recordMetric(name, duration);
    };
  }
  
  recordMetric(name: string, value: number) {
    if (!this.metrics.has(name)) {
      this.metrics.set(name, []);
    }
    
    const values = this.metrics.get(name)!;
    values.push(value);
    
    // Keep last 100 values
    if (values.length > 100) {
      values.shift();
    }
    
    // Send to analytics if threshold exceeded
    if (name === 'tile_load' && value > 1000) {
      this.reportSlowLoad(name, value);
    }
  }
  
  getStats(name: string) {
    const values = this.metrics.get(name) || [];
    
    if (values.length === 0) {
      return null;
    }
    
    const sorted = [...values].sort((a, b) => a - b);
    
    return {
      min: sorted[0],
      max: sorted[sorted.length - 1],
      median: sorted[Math.floor(sorted.length / 2)],
      p95: sorted[Math.floor(sorted.length * 0.95)],
      average: values.reduce((a, b) => a + b, 0) / values.length
    };
  }
  
  private reportSlowLoad(metric: string, value: number) {
    // Send to monitoring service
    fetch('/api/metrics/slow', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        metric,
        value,
        context: {
          viewport: `${window.innerWidth}x${window.innerHeight}`,
          connection: (navigator as any).connection?.effectiveType,
          memory: (performance as any).memory?.usedJSHeapSize
        }
      })
    });
  }
}

export const perfMonitor = new MapPerformanceMonitor();
```

---

## Maintenance and Updates

### Version Management

```typescript
// Version check and migration
class MapVersionManager {
  private currentVersion = '1.0.0';
  
  async checkForUpdates() {
    const response = await fetch('/api/map/version');
    const { version, features } = await response.json();
    
    if (this.isNewer(version, this.currentVersion)) {
      await this.migrate(this.currentVersion, version);
      this.currentVersion = version;
    }
    
    return features;
  }
  
  private isNewer(v1: string, v2: string): boolean {
    const parts1 = v1.split('.').map(Number);
    const parts2 = v2.split('.').map(Number);
    
    for (let i = 0; i < 3; i++) {
      if (parts1[i] > parts2[i]) return true;
      if (parts1[i] < parts2[i]) return false;
    }
    
    return false;
  }
  
  private async migrate(from: string, to: string) {
    console.log(`Migrating from ${from} to ${to}`);
    
    // Clear old caches
    if ('caches' in window) {
      const names = await caches.keys();
      await Promise.all(
        names
          .filter(name => name.includes('map') && !name.includes(to))
          .map(name => caches.delete(name))
      );
    }
    
    // Update stored preferences
    const stored = localStorage.getItem('findr-map-state');
    if (stored) {
      const state = JSON.parse(stored);
      state.version = to;
      localStorage.setItem('findr-map-state', JSON.stringify(state));
    }
  }
}
```

### Feature Flags

```typescript
// Feature flag system
interface FeatureFlags {
  ebwbl: boolean;
  offline: boolean;
  threeDView: boolean;
  crowdsourcedData: boolean;
  aiPredictions: boolean;
}

class FeatureFlagManager {
  private flags: FeatureFlags = {
    ebwbl: true,
    offline: true,
    threeDView: false,
    crowdsourcedData: false,
    aiPredictions: false
  };
  
  async loadFlags() {
    try {
      const response = await fetch('/api/features');
      const remoteFlags = await response.json();
      
      this.flags = { ...this.flags, ...remoteFlags };
    } catch (error) {
      // Use default flags
      console.warn('Failed to load feature flags, using defaults');
    }
  }
  
  isEnabled(feature: keyof FeatureFlags): boolean {
    return this.flags[feature] || false;
  }
  
  // A/B testing support
  getVariant(feature: string): string {
    const userId = this.getUserId();
    const hash = this.hashCode(`${feature}-${userId}`);
    
    return hash % 2 === 0 ? 'A' : 'B';
  }
  
  private getUserId(): string {
    let id = localStorage.getItem('findr-user-id');
    
    if (!id) {
      id = crypto.randomUUID();
      localStorage.setItem('findr-user-id', id);
    }
    
    return id;
  }
  
  private hashCode(str: string): number {
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
      const char = str.charCodeAt(i);
      hash = ((hash << 5) - hash) + char;
      hash = hash & hash; // Convert to 32-bit integer
    }
    return Math.abs(hash);
  }
}

export const featureFlags = new FeatureFlagManager();
```

---

## Claude Code Instructions

When implementing this feature with Claude Code:

1. **Start with core components**: Implement FullScreenMap.tsx and useEBWBLLayer.ts first
2. **Test EBWBL availability early**: Use the test endpoints to verify access
3. **Implement fallbacks incrementally**: Start with EBWBL → Standard, then add caching
4. **Mobile-first approach**: Test on mobile devices frequently during development
5. **Performance monitoring**: Add metrics from the beginning to track improvements
6. **Progressive enhancement**: Ship basic version first, add features iteratively

### Implementation Order:

```
Phase 1 (MVP - Days 1-3):
├── Basic map component
├── EBWBL loading
├── Standard fallback
└── Layer controls

Phase 2 (Enhancement - Days 4-5):
├── Tile caching
├── Service worker
├── Offline mode
└── Performance metrics

Phase 3 (Polish - Days 6-7):
├── Animations
├── Error boundaries
├── Analytics
└── Documentation

Phase 4 (Testing - Days 8-10):
├── Unit tests
├── Integration tests
├── Performance testing
└── User acceptance testing
```

---

## Success Criteria

The implementation is considered successful when:

1. **Functional Requirements**:
   - ✅ Full-screen map loads in <2s
   - ✅ EBWBL loads when available
   - ✅ Automatic fallback to standard EMODnet
   - ✅ Offline mode works with cached tiles
   - ✅ Layer switching is smooth (<1s)

2. **Performance Requirements**:
   - ✅ 60fps scrolling and zooming
   - ✅ <100MB memory usage
   - ✅ >60% cache hit rate for returning users
   - ✅ <500ms tile load time (p95)

3. **User Experience**:
   - ✅ Clear quality indicators
   - ✅ Smooth transitions
   - ✅ Mobile gestures work properly
   - ✅ Accessible via keyboard
   - ✅ Works offline for cached areas

4. **Technical Requirements**:
   - ✅ TypeScript with no errors
   - ✅ 80% test coverage
   - ✅ Lighthouse score >90
   - ✅ Bundle size <200KB (gzipped)

---

This comprehensive guide provides everything needed to implement the EBWBL map feature for Findr. The implementation follows best practices for performance, accessibility, and user experience while maintaining code quality and testability.
