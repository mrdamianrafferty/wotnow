// /src/components/MapView/MiniMap.tsx

import React, { useEffect, useRef, useState } from 'react';
import { useRouter } from 'next/navigation';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import { Expand, MapPin } from 'lucide-react';
import { LayerTeaser } from './LayerControls';

interface MiniMapProps {
  center: [number, number];
  zoom?: number;
  spotName?: string;
  spotId?: string;
  bbox?: [[number, number], [number, number]];
  onExpand?: () => void;
}

export const MiniMap: React.FC<MiniMapProps> = ({
  center,
  zoom = 12,
  spotName,
  spotId,
  bbox,
  onExpand
}) => {
  const router = useRouter();
  const mapContainer = useRef<HTMLDivElement>(null);
  const mapInstance = useRef<L.Map | null>(null);
  const [isMapReady, setIsMapReady] = useState(false);

  useEffect(() => {
    if (!mapContainer.current || mapInstance.current) return;

    // Initialize map with minimal options for performance
    const map = L.map(mapContainer.current, {
      center,
      zoom,
      zoomControl: false,
      attributionControl: false,
      dragging: false, // Disable dragging for mini map
      touchZoom: false,
      doubleClickZoom: false,
      scrollWheelZoom: false,
      boxZoom: false,
      keyboard: false,
      tap: false
    });

    // Add simple base layer
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      maxZoom: 19,
      attribution: '© OpenStreetMap'
    }).addTo(map);

    // Add spot marker if we have a center
    const spotIcon = L.divIcon({
      html: `
        <div class="relative">
          <div class="absolute -inset-2 bg-primary opacity-40 rounded-full animate-ping"></div>
          <svg class="h-6 w-6 text-primary drop-shadow-lg" fill="currentColor" viewBox="0 0 24 24">
            <path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z"/>
          </svg>
        </div>
      `,
      className: 'custom-marker',
      iconSize: [24, 24],
      iconAnchor: [12, 24]
    });

    L.marker(center, { icon: spotIcon }).addTo(map);

    // Add bounding box if provided
    if (bbox) {
      L.rectangle(bbox, {
        color: '#3b82f6',
        weight: 2,
        opacity: 0.4,
        fill: true,
        fillOpacity: 0.1,
        dashArray: '5, 5'
      }).addTo(map);
    }

    // Add subtle depth indicator overlay (visual teaser only)
    if (center[0] > 40 && center[0] < 45) { // Rough check for Spanish waters
      const depthGradient = L.circle(center, {
        radius: 2000,
        color: '#1e40af',
        weight: 1,
        opacity: 0.3,
        fillColor: '#3b82f6',
        fillOpacity: 0.1
      }).addTo(map);
    }

    mapInstance.current = map;
    setIsMapReady(true);

    // Handle click to expand
    map.on('click', handleExpandMap);

    return () => {
      map.off('click', handleExpandMap);
      map.remove();
      mapInstance.current = null;
    };
  }, []);

  const handleExpandMap = () => {
    if (onExpand) {
      onExpand();
    } else {
      // Navigate to full-screen map with state
      const params = new URLSearchParams({
        lat: center[0].toString(),
        lon: center[1].toString(),
        z: zoom.toString(),
        layer: 'depth' // Default to depth view
      });
      
      if (spotId) params.append('spot', spotId);
      
      router.push(`/map/full?${params.toString()}`);
    }
  };

  return (
    <div className="relative">
      {/* Map Container */}
      <div className="relative h-56 md:h-64 rounded-xl overflow-hidden border border-base-300 bg-base-200 group cursor-pointer">
        <div ref={mapContainer} className="absolute inset-0" />
        
        {/* Loading State */}
        {!isMapReady && (
          <div className="absolute inset-0 flex items-center justify-center bg-base-200">
            <span className="loading loading-spinner loading-md" />
          </div>
        )}

        {/* Overlay Gradient for Visual Interest */}
        <div className="absolute inset-0 bg-gradient-to-t from-base-100/20 to-transparent pointer-events-none" />

        {/* Location Badge */}
        {spotName && (
          <div className="absolute top-2 left-2 z-10">
            <div className="badge badge-sm bg-base-100/90 backdrop-blur gap-1">
              <MapPin className="h-3 w-3" />
              {spotName}
            </div>
          </div>
        )}

        {/* Expand Button */}
        <button
          onClick={handleExpandMap}
          className="btn btn-primary btn-sm rounded-full absolute bottom-3 right-3 shadow-lg gap-1 opacity-90 hover:opacity-100 transition-opacity"
          aria-label="Expand map to full screen"
        >
          <Expand className="h-4 w-4" />
          <span className="hidden sm:inline">Expand map</span>
          <span className="sm:hidden">Map</span>
        </button>

        {/* Hover Effect Overlay */}
        <div className="absolute inset-0 bg-primary/5 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none" />
      </div>

      {/* Layer Teaser Below Map */}
      <div className="mt-2 px-1">
        <LayerTeaser onExpand={handleExpandMap} />
        
        {/* Additional Info */}
        <p className="text-xs opacity-60 mt-2">
          Tap map to explore bathymetry and seabed layers
        </p>
      </div>
    </div>
  );
};

// Alternative compact version for list views
export const MiniMapCompact: React.FC<{
  center: [number, number];
  spotName: string;
  onClick: () => void;
}> = ({ center, spotName, onClick }) => {
  const mapContainer = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!mapContainer.current) return;

    const map = L.map(mapContainer.current, {
      center,
      zoom: 10,
      zoomControl: false,
      attributionControl: false,
      dragging: false,
      touchZoom: false,
      doubleClickZoom: false,
      scrollWheelZoom: false,
      boxZoom: false,
      keyboard: false,
      tap: false
    });

    // Simple tile layer
    L.tileLayer('https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}.png', {
      maxZoom: 19
    }).addTo(map);

    // Simple marker
    L.circleMarker(center, {
      radius: 5,
      fillColor: '#3b82f6',
      color: '#fff',
      weight: 2,
      opacity: 1,
      fillOpacity: 0.8
    }).addTo(map);

    return () => {
      map.remove();
    };
  }, [center]);

  return (
    <div 
      className="relative h-24 w-full rounded-lg overflow-hidden cursor-pointer group"
      onClick={onClick}
    >
      <div ref={mapContainer} className="absolute inset-0" />
      <div className="absolute inset-0 bg-gradient-to-t from-base-100/50 to-transparent" />
      
      {/* Spot name overlay */}
      <div className="absolute bottom-1 left-1">
        <span className="badge badge-xs badge-ghost">
          {spotName}
        </span>
      </div>
      
      {/* Hover overlay */}
      <div className="absolute inset-0 bg-primary/10 opacity-0 group-hover:opacity-100 transition-opacity" />
    </div>
  );
};