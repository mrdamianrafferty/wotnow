// /src/hooks/useEBWBLLayer.ts

import { useCallback, useRef, useState } from 'react';
import L from 'leaflet';

interface LayerConfig {
  ebwbl: {
    bathymetry: {
      url: string;
      attribution: string;
      maxZoom: number;
      minZoom: number;
    };
  };
  standard: {
    bathymetry: {
      url: string;
      layers: string;
      format: string;
      attribution: string;
    };
    substrate: {
      url: string;
      layers: string;
      format: string;
      attribution: string;
    };
  };
}

// Service configuration
const SERVICES: LayerConfig = {
  ebwbl: {
    bathymetry: {
      url: 'https://tiles.emodnet-bathymetry.eu/2020/baselayer/{z}/{x}/{y}.png',
      attribution: '© EMODnet Bathymetry Consortium (EBWBL)',
      maxZoom: 14,
      minZoom: 2
    }
  },
  standard: {
    bathymetry: {
      url: 'https://ows.emodnet-bathymetry.eu/wms',
      layers: 'emodnet:mean_atlas_land',
      format: 'image/png',
      attribution: '© EMODnet Bathymetry Consortium'
    },
    substrate: {
      url: 'https://ows.emodnet-geology.eu/geoserver/emodnet/wms',
      layers: 'seabed_substrate_1m',
      format: 'image/png',
      attribution: '© EMODnet Geology'
    }
  }
};

export const useEBWBLLayer = () => {
  const currentLayers = useRef<L.Layer[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [currentSource, setCurrentSource] = useState<'EBWBL' | 'EMODnet' | null>(null);

  // Test EBWBL availability
  const testEBWBLAvailability = useCallback(async (): Promise<boolean> => {
    try {
      // Test load a single tile to check availability
      const testUrl = SERVICES.ebwbl.bathymetry.url
        .replace('{z}', '4')
        .replace('{x}', '8')
        .replace('{y}', '5');
      
      const response = await fetch(testUrl, { 
        method: 'HEAD',
        mode: 'cors',
        cache: 'no-cache'
      });
      
      return response.ok;
    } catch (error) {
      console.warn('EBWBL not available:', error);
      return false;
    }
  }, []);

  // Load EBWBL layer
  const loadEBWBLLayer = useCallback(async (
    map: L.Map, 
    type: 'bathymetry'
  ): Promise<boolean> => {
    setIsLoading(true);
    
    try {
      // Check if EBWBL is available
      const isAvailable = await testEBWBLAvailability();
      
      if (!isAvailable) {
        console.log('EBWBL not available, will use fallback');
        return false;
      }

      // Create EBWBL tile layer
      const ebwblLayer = L.tileLayer(SERVICES.ebwbl.bathymetry.url, {
        attribution: SERVICES.ebwbl.bathymetry.attribution,
        maxZoom: SERVICES.ebwbl.bathymetry.maxZoom,
        minZoom: SERVICES.ebwbl.bathymetry.minZoom,
        className: 'ebwbl-tiles',
        crossOrigin: true,
        opacity: 0.8,
        errorTileUrl: 'data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7' // Transparent pixel
      });

      // Add error handling
      let hasError = false;
      ebwblLayer.on('tileerror', (error) => {
        console.warn('EBWBL tile error:', error);
        hasError = true;
      });

      // Add to map
      ebwblLayer.addTo(map);
      currentLayers.current.push(ebwblLayer);

      // Wait a bit to see if tiles load successfully
      await new Promise(resolve => setTimeout(resolve, 500));

      if (hasError) {
        // Remove failed layer and return false
        map.removeLayer(ebwblLayer);
        currentLayers.current = currentLayers.current.filter(l => l !== ebwblLayer);
        return false;
      }

      setCurrentSource('EBWBL');
      setIsLoading(false);
      
      console.log('EBWBL layer loaded successfully');
      return true;

    } catch (error) {
      console.error('Error loading EBWBL:', error);
      setIsLoading(false);
      return false;
    }
  }, [testEBWBLAvailability]);

  // Fallback to standard EMODnet
  const fallbackToStandard = useCallback(async (
    map: L.Map,
    type: 'bathymetry' | 'substrate'
  ): Promise<boolean> => {
    setIsLoading(true);
    
    try {
      const config = SERVICES.standard[type];
      
      // Create WMS layer
      const wmsLayer = L.tileLayer.wms(config.url, {
        layers: config.layers,
        format: config.format,
        transparent: true,
        attribution: config.attribution,
        opacity: 0.7,
        version: '1.3.0',
        crs: L.CRS.EPSG3857
      });

      // Add to map
      wmsLayer.addTo(map);
      currentLayers.current.push(wmsLayer);
      
      setCurrentSource('EMODnet');
      setIsLoading(false);
      
      console.log(`Standard EMODnet ${type} layer loaded`);
      return true;

    } catch (error) {
      console.error('Error loading standard layer:', error);
      setIsLoading(false);
      return false;
    }
  }, []);

  // Clear all overlay layers
  const clearLayers = useCallback((map: L.Map) => {
    currentLayers.current.forEach(layer => {
      map.removeLayer(layer);
    });
    currentLayers.current = [];
    setCurrentSource(null);
  }, []);

  // Get legend URL for current layer
  const getLegendUrl = useCallback((type: 'bathymetry' | 'substrate'): string | null => {
    if (type === 'bathymetry' && currentSource === 'EBWBL') {
      // EBWBL legend
      return 'https://tiles.emodnet-bathymetry.eu/legend/legend_baselayer.png';
    } else if (type === 'bathymetry') {
      // Standard bathymetry legend
      return `${SERVICES.standard.bathymetry.url}?SERVICE=WMS&VERSION=1.3.0&REQUEST=GetLegendGraphic&LAYER=${SERVICES.standard.bathymetry.layers}&FORMAT=image/png`;
    } else if (type === 'substrate') {
      // Substrate legend
      return `${SERVICES.standard.substrate.url}?SERVICE=WMS&VERSION=1.3.0&REQUEST=GetLegendGraphic&LAYER=${SERVICES.standard.substrate.layers}&FORMAT=image/png`;
    }
    return null;
  }, [currentSource]);

  return {
    loadEBWBLLayer,
    fallbackToStandard,
    clearLayers,
    getLegendUrl,
    isLoading,
    currentSource
  };
};

// Hook for preloading tiles in background
export const useMapPreloader = (map: L.Map | null) => {
  const preloadArea = useCallback(async (
    bounds: L.LatLngBounds,
    zoom: number,
    source: 'EBWBL' | 'EMODnet'
  ) => {
    if (!map) return;

    const tiles = calculateTilesInBounds(bounds, zoom);
    
    // Preload in chunks to avoid overwhelming the browser
    const chunks = chunkArray(tiles, 4);
    
    for (const chunk of chunks) {
      await Promise.all(
        chunk.map(tile => preloadTile(tile, source))
      );
      // Small delay between chunks
      await new Promise(resolve => setTimeout(resolve, 100));
    }
  }, [map]);

  return { preloadArea };
};

// Helper functions
function calculateTilesInBounds(
  bounds: L.LatLngBounds, 
  zoom: number
): Array<{x: number; y: number; z: number}> {
  const tiles: Array<{x: number; y: number; z: number}> = [];
  
  const nwTile = latLngToTile(bounds.getNorthWest(), zoom);
  const seTile = latLngToTile(bounds.getSouthEast(), zoom);
  
  for (let x = nwTile.x; x <= seTile.x; x++) {
    for (let y = nwTile.y; y <= seTile.y; y++) {
      tiles.push({ x, y, z: zoom });
    }
  }
  
  return tiles;
}

function latLngToTile(latLng: L.LatLng, zoom: number): {x: number; y: number} {
  const x = Math.floor((latLng.lng + 180) / 360 * Math.pow(2, zoom));
  const y = Math.floor((1 - Math.log(
    Math.tan(latLng.lat * Math.PI / 180) + 
    1 / Math.cos(latLng.lat * Math.PI / 180)
  ) / Math.PI) / 2 * Math.pow(2, zoom));
  
  return { x, y };
}

function chunkArray<T>(array: T[], size: number): T[][] {
  const chunks: T[][] = [];
  for (let i = 0; i < array.length; i += size) {
    chunks.push(array.slice(i, i + size));
  }
  return chunks;
}

async function preloadTile(
  tile: {x: number; y: number; z: number},
  source: 'EBWBL' | 'EMODnet'
): Promise<void> {
  const url = source === 'EBWBL' 
    ? SERVICES.ebwbl.bathymetry.url
        .replace('{z}', tile.z.toString())
        .replace('{x}', tile.x.toString())
        .replace('{y}', tile.y.toString())
    : `${SERVICES.standard.bathymetry.url}?SERVICE=WMS&VERSION=1.3.0&REQUEST=GetMap&LAYERS=${SERVICES.standard.bathymetry.layers}&BBOX=${tileToBBox(tile)}&WIDTH=256&HEIGHT=256&CRS=EPSG:3857&FORMAT=image/png`;

  try {
    // Just fetch to cache, don't need to process
    await fetch(url, { mode: 'cors', cache: 'force-cache' });
  } catch (error) {
    // Silent fail for preloading
  }
}

function tileToBBox(tile: {x: number; y: number; z: number}): string {
  const n = Math.pow(2, tile.z);
  const lon1 = tile.x / n * 360 - 180;
  const lat1 = Math.atan(Math.sinh(Math.PI * (1 - 2 * tile.y / n))) * 180 / Math.PI;
  const lon2 = (tile.x + 1) / n * 360 - 180;
  const lat2 = Math.atan(Math.sinh(Math.PI * (1 - 2 * (tile.y + 1) / n))) * 180 / Math.PI;
  
  // Convert to Web Mercator
  const bounds = L.bounds(
    L.CRS.EPSG3857.project(L.latLng(lat2, lon1)),
    L.CRS.EPSG3857.project(L.latLng(lat1, lon2))
  );
  
  return `${bounds.min.x},${bounds.min.y},${bounds.max.x},${bounds.max.y}`;
}
