
from skyfield.api import load, wgs84
from skyfield import almanac
from datetime import datetime, timedelta, timezone

def load_ephemerides():
    ts = load.timescale()
    try:
        eph = load('de440s.bsp')
    except Exception:
        eph = load('de421.bsp')
    return type('E', (), {'ts':ts, 'eph':eph})

def moon_phase_fraction(eph, ts, t):
    e = almanac.moon_phase(eph, t)
    import math
    phase_deg = e.degrees
    illum = 0.5*(1 - math.cos(math.radians(phase_deg))) * 100.0
    return phase_deg/360.0, illum

def day_span(start_date, days):
    return [datetime.fromisoformat(start_date) + timedelta(days=i) for i in range(days)]

def sun_moon_times(lat, lon, date_d, eph, ts):
    topos = wgs84.latlon(latitude_degrees=lat, longitude_degrees=lon)
    t0 = ts.utc(date_d.year, date_d.month, date_d.day, 0)
    t1 = ts.utc((date_d + timedelta(days=1)).year, (date_d + timedelta(days=1)).month, (date_d + timedelta(days=1)).day, 0)

    # twilight
    f = almanac.dark_twilight_day(eph, topos)
    times, events = almanac.find_discrete(t0, t1, f)
    sun = {}
    astro_dark_start = None; astro_dark_end=None
    for t,e in zip(times, events):
        if e == almanac.NIGHT and astro_dark_start is None:
            astro_dark_start = t.utc_datetime().replace(tzinfo=timezone.utc).isoformat()
        elif e == almanac.ASTRONOMICAL_TWILIGHT and astro_dark_start and not astro_dark_end:
            astro_dark_end = t.utc_datetime().replace(tzinfo=timezone.utc).isoformat()
    if astro_dark_start: sun['astro_dark_start']=astro_dark_start
    if astro_dark_end: sun['astro_dark_end']=astro_dark_end

    # sunrise/sunset
    f2 = almanac.sunrise_sunset(eph, topos)
    t2,e2 = almanac.find_discrete(t0, t1, f2)
    for t,e in zip(t2,e2):
        if e: sun['sunrise'] = t.utc_datetime().replace(tzinfo=timezone.utc).isoformat()
        else: sun['sunset'] = t.utc_datetime().replace(tzinfo=timezone.utc).isoformat()

    # moon rise/set
    f3 = almanac.risings_and_settings(eph, eph['Moon'], topos)
    t3,e3 = almanac.find_discrete(t0, t1, f3)
    moon = {}
    for t,e in zip(t3,e3):
        if e: moon['rise'] = t.utc_datetime().replace(tzinfo=timezone.utc).isoformat()
        else: moon['set']  = t.utc_datetime().replace(tzinfo=timezone.utc).isoformat()

    phase_frac, illum_pct = moon_phase_fraction(eph, ts, ts.utc(date_d.year, date_d.month, date_d.day, 12))
    moon['phase'] = round(phase_frac, 3)
    moon['illumination'] = round(illum_pct, 1)
    return sun, moon


def illumination_at(eph, ts, iso_utc: str) -> float:
    """Return illumination percent at a given UTC ISO timestamp."""
    from datetime import datetime, timezone
    from skyfield import almanac
    import math
    try:
        dt = datetime.fromisoformat(iso_utc.replace('Z', '+00:00')).astimezone(timezone.utc)
    except Exception:
        return 50.0
    phase_deg = almanac.moon_phase(eph, ts.from_datetime(dt)).degrees
    illum = 0.5 * (1 - math.cos(math.radians(phase_deg))) * 100.0
    return float(illum)
