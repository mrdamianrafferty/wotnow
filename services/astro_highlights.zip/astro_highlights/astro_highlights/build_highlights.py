
import argparse, json
from .data_ingest import load_meteor_showers, load_eclipses
from .compute import load_ephemerides, day_span, sun_moon_times, illumination_at
from datetime import datetime, timedelta

def parse_args():
    ap = argparse.ArgumentParser()
    ap.add_argument('--lat', type=float, required=True)
    ap.add_argument('--lon', type=float, required=True)
    ap.add_argument('--date', type=str, default=datetime.utcnow().date().isoformat())
    ap.add_argument('--days', type=int, default=1)
    ap.add_argument('--out', type=str, default='highlights.json')
    ap.add_argument('--cloud-avg', type=float, default=None, help='Average cloud cover 0-100 (optional)')
    ap.add_argument('--cloud-file', type=str, default=None, help='Path to JSON with hourly cloud cover {"hourly":[{"time":"ISO","cloud":%}]}' )
    return ap.parse_args()

def filter_showers(showers, date_d):
    out=[]; 
    for s in showers.get('showers', []):
        sd = datetime.fromisoformat(s['active_start']).date()
        ed = datetime.fromisoformat(s['active_end']).date()
        if sd <= date_d.date() <= ed:
            out.append({'id':s['id'], 'name':s['name'], 'peak_utc':s.get('peak_utc','')})
    return out

def filter_eclipses(rows, date_d, window_days=400):
    from datetime import timedelta
    out=[]; lo = date_d - timedelta(days=window_days); hi = date_d + timedelta(days=window_days)
    for r in rows:
        try: t = datetime.fromisoformat(r['date_utc'].replace('Z','+00:00'))
        except: continue
        if lo <= t <= hi: out.append(r)
    return out

def build_highlights(lat, lon, start_date, days):
    ephe = load_ephemerides()
    start_dt = datetime.fromisoformat(start_date)
    nights=[]
    showers = load_meteor_showers(start_dt.year)
    solar = load_eclipses('solar'); lunar = load_eclipses('lunar')
    for d in day_span(start_date, days):
        sun, moon = sun_moon_times(lat, lon, d, ephe.eph, ephe.ts)
        act = filter_showers(showers, d)
        eclipses = filter_eclipses(solar, d, 400) + filter_eclipses(lunar, d, 400)
        nights.append({'date': d.date().isoformat(), 'sun': sun, 'moon': moon,
                       'showers_active': act, 'eclipses_upcoming': eclipses[:5]})
    return {'location': {'lat': lat, 'lon': lon, 'tz': 'auto'},
            'date_span': {'start': start_dt.date().isoformat(), 'days': days},
            'nights': nights}

def main():
    args = parse_args()
    h = build_highlights(args.lat, args.lon, args.date, args.days)
    # Optional clouds
    cloud_series = None
    if args.cloud_file:
        try:
            with open(args.cloud_file, 'r', encoding='utf-8') as cf:
                cloud_json = json.load(cf)
                cloud_series = cloud_json.get('hourly') or cloud_json.get('hours')
        except Exception:
            cloud_series = None
    ephe = load_ephemerides()
    for night in h.get('nights', []):
        night['dark_sky'] = dark_sky_score(night, args.cloud_avg, cloud_series, ephe.eph, ephe.ts)
    with open(args.out, 'w', encoding='utf-8') as f:
        json.dump(h, f, indent=2)
    print('Wrote', args.out)

if __name__ == '__main__':
    main()


def dark_sky_score(night: dict, cloud_avg: float | None, cloud_series: list | None, eph, ts) -> dict:
    """Compute a Dark Sky Score 0..100 using astronomical darkness, moonlight and clouds."""
    from datetime import datetime, timezone

    sun = night.get('sun', {})
    start = sun.get('astro_dark_start')
    end = sun.get('astro_dark_end')
    if not start or not end:
        return {'score': 0, 'components': {'dark_hours': 0, 'darkness_factor': 0, 'moon_darkness': 0, 'clear_sky': None}}

    dt_start = datetime.fromisoformat(start.replace('Z','+00:00')).astimezone(timezone.utc)
    dt_end = datetime.fromisoformat(end.replace('Z','+00:00')).astimezone(timezone.utc)
    dark_hours = max((dt_end - dt_start).total_seconds() / 3600.0, 0.0)

    # Normalise darkness duration vs an 8h reference window
    darkness_factor = min(dark_hours / 8.0, 1.0)

    # Sample moon illumination at middle of dark window
    mid_iso = (dt_start + (dt_end - dt_start) / 2).isoformat()
    illum_pct = illumination_at(eph, ts, mid_iso)
    moon_darkness = max(0.0, min(1.0, 1.0 - (illum_pct / 100.0)))  # 1 means no moonlight

    # Cloud factor
    clear_sky = None
    if cloud_series:
        vals = []
        for row in cloud_series:
            try:
                t = datetime.fromisoformat(str(row.get('time')).replace('Z','+00:00')).astimezone(timezone.utc)
                if dt_start <= t <= dt_end:
                    vals.append(float(row.get('cloud', 0)))
            except Exception:
                continue
        if vals:
            cloud_avg = sum(vals) / len(vals)
    if cloud_avg is not None:
        clear_sky = max(0.0, min(1.0, 1.0 - (float(cloud_avg) / 100.0)))

    # Weights
    w_dark = 0.4
    w_moon = 0.4
    w_cloud = 0.2 if clear_sky is not None else 0.0
    weight_sum = w_dark + w_moon + w_cloud

    raw = (darkness_factor * w_dark) + (moon_darkness * w_moon) + ((clear_sky or 0.0) * w_cloud)
    score = int(round((raw / weight_sum) * 100)) if weight_sum > 0 else 0

    return {'score': max(0, min(100, score)),
            'components': {
                'dark_hours': round(dark_hours, 2),
                'darkness_factor': round(darkness_factor, 3),
                'moon_darkness': round(moon_darkness, 3),
                'clear_sky': None if clear_sky is None else round(clear_sky, 3),
                'illumination_pct_mid_dark': round(illum_pct, 1)
            }}
